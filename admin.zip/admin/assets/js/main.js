$.noConflict();
jQuery(document).ready(function ($) {
  "use strict";
  [].slice
    .call(document.querySelectorAll("select.cs-select"))
    .forEach(function (el) {
      new SelectFx(el);
    });
  jQuery(".selectpicker").selectpicker;
  $(".search-trigger").on("click", function (event) {
    event.preventDefault();
    event.stopPropagation();
    $(".search-trigger").parent(".header-left").addClass("open");
  });
  $(".search-close").on("click", function (event) {
    event.preventDefault();
    event.stopPropagation();
    $(".search-trigger").parent(".header-left").removeClass("open");
  });
  $(".equal-height").matchHeight({ property: "max-height" });
  $(".count").each(function () {
    $(this)
      .prop("Counter", 0)
      .animate(
        { Counter: $(this).text() },
        {
          duration: 3000,
          easing: "swing",
          step: function (now) {
            $(this).text(Math.ceil(now));
          },
        }
      );
  });
  $("#menuToggle").on("click", function (event) {
    var windowWidth = $(window).width();
    if (windowWidth < 1010) {
      $("body").removeClass("open");
      if (windowWidth < 760) {
        $("#left-panel").slideToggle();
      } else {
        $("#left-panel").toggleClass("open-menu");
      }
    } else {
      $("body").toggleClass("open");
      $("#left-panel").removeClass("open-menu");
    }
  });
  $(".menu-item-has-children.dropdown").each(function () {
    $(this).on("click", function () {
      var $temp_text = $(this).children(".dropdown-toggle").html();
      $(this)
        .children(".sub-menu")
        .prepend('<li class="subtitle">' + $temp_text + "</li>");
    });
  });
  $(window).on("load resize", function (event) {
    var windowWidth = $(window).width();
    if (windowWidth < 1010) {
      $("body").addClass("small-device");
    } else {
      $("body").removeClass("small-device");
    }
  });
  $('#tbl_families').DataTable({
    responsive: true,
    lengthChange: false
  });
  $('#tbl_members').DataTable({
    responsive: true,
    lengthChange: false
  });
  function start_loader(){
    $('body').prepend('<div id="preloader"></div>')
  }
  $('#print').click(function(){
    console.log('print');
          var _h = $("head").clone()
          var _p = $('#outprint').clone()
          var el = $("<div>")
          start_loader()
          $('script').each(function(){
              if(_h.find('script[src="'+$(this).attr('src')+'"]').length <= 0){
                  _h.append($(this).clone())
              }
          })
          _h.find('title').text("Certificate of Baptism - Print View")
          // _p.prepend("<hr class='border-navy '>")
          // _p.prepend("<div class='mx-5 py-4'><h1 class='text-center'><?= $_settings->info('church_name') ?></h1>"
          //             +"<center><small class='text-muted'><?= $_settings->info('address') ?></small></center></div>")
          // _p.prepend("<img src='<?= validate_image($_settings->info('logo')) ?>' id='print-logo' />")
          el.append(_h)
          el.append(_p)

          var nw = window.open("","_blank","height=800,width=1200,left=200")
              nw.document.write(el.html())
              nw.document.close()
              setTimeout(()=>{
                  nw.print()
                  setTimeout(() => {
                      nw.close()
                      end_loader()
                  }, 300);
              },300)
      })

      function toggleFields(checkbox) {
        var event = checkbox.data('event');
        var fields = $('.' + event + '-fields');
        if (checkbox.prop('checked') && event != 'alive') {
            fields.show();
        } else if (!checkbox.prop('checked') && event == 'alive') {
          fields.show();
      } else {
            fields.hide();
        }
    }

    // Initial state
    $('.event-checkbox').each(function() {
        toggleFields($(this));
    });

    // Add change event listener to all checkboxes with class .event-checkbox
    $('.event-checkbox').change(function() {
        toggleFields($(this));
    });

	// Define common validation rules and options
	var commonRulesAndOptions = {
		rules: {
			family_name: {
				required: true,
			},
			family_no: {
				required: true,
			},
			anbiyam: {
			required: true,
			},
			substation: {
			required: true,
			},
			native: {
			required: true,
			},
			contact_number: {
			required: true,
			},
			whatsapp_number: {
			required: true,
			},
			subscription: {
			required: true,
			},
			house: {
			required: true,
			},
			cemetery: {
			required: true,
			},
			address: {
			required: true,
			},
			member_name: {
			required: true,
			},
			relationship: {
			required: true,
			},
			gender: {
			required: true,
			},
			dob: {
			required: true,
			},
			birth_place: {
			required: true,
			},
			qualification: {
			required: true,
			},
			occupation: {
			required: true,
			},
		},
		messages: {
			family_name: {
				required: "Family name is required",
			},
			family_no: {
				required: "Card numbers is required",
			},
			anbiyam: {
			required: "Anbiyam is required",
			},
			substation: {
			required: "Substation is required",
			},
			native: {
			required: "Native is required",
			},
			contact_number: {
			required: "Contact number is required",
			},
			whatsapp_number: {
			required: "WhatsApp number is required",
			},
			subscription: {
			required: "Subscription is required",
			},
			house: {
			required: "House is required",
			},
			cemetery: {
			required: "Cemetery is required",
			},
			address: {
			required: "Address is required",
			},
			member_name: {
			required: "Member name is required",
			},
			relationship: {
			required: "Relationship is required",
			},
			gender: {
			required: "Gender is required",
			},
			dob: {
			required: "Dob is required",
			},
			birth_place: {
			required: "Birth place is required",
			},
			qualification: {
			required: "Qualification is required",
			},
			occupation: {
			required: "Occupation is required",
			},
		},
		errorElement: "span",
		errorClass: 'invalid-feedback',
		highlight: function(element, errorClass, validClass) {
			$(element).addClass("is-invalid");
		},
		unhighlight: function(element, errorClass, validClass) {
			$(element).removeClass("is-invalid");
		}
	};

	// Initialize validator for each form
	$("#family_form, #member_form").each(function() {
		var $form = $(this);
		var validator = $form.validate(commonRulesAndOptions);

		// Additional validation rules for specific checkboxes
		$form.find(".event-checkbox").change(function() {
			var isChecked = $(this).is(":checked");
			if (validator) { // Check if validator object exists
				var checkboxName = $(this).attr("name");
				validator.settings.rules[checkboxName + "_date"] = { required: isChecked };
				validator.settings.rules[checkboxName + "_place"] = { required: isChecked };
				validator.resetForm(); // Reset validation state
			}
		}).change(); // Trigger the change event initially

		// Manually trigger validation when the form is submitted
		$form.submit(function(e) {
			e.preventDefault();
			var accordionSections = $form.find(".accordion-item");
			accordionSections.each(function() {
				if (!$(this).hasClass("show")) {
					$(this).addClass("show");
				}
			});
			if (validator) {
				var isValid = validator.form(); // Validate the form
				if (isValid) {
					$form.off('submit').submit(); // Submit the form
				}
			}
			return true; // Proceed with form submission if validator is not initialized
		});
	});

});
