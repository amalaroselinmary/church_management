<?php
require('top.inc.php');
isAdmin();
$msg='';
$id= isset($_GET['id']) ? get_safe_value($con,$_GET['id']): "";

if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from communion_list where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
        $father_name = $row['father_name'];
        $mother_name = $row['mother_name'];
		$member_id = $row['member_id'];

        $member_res=mysqli_query($con,"select * from family_members where id='$member_id'");
        $result=mysqli_num_rows($res);
        if($result>0){
            $row1=mysqli_fetch_assoc($member_res);
            $member_name = $row1['member_name'];
            $gender = $row1['gender'];
            $dob = $row1['dob'];
            $birth_place = $row1['birth_place'];
            $baptism_date = $row1['baptism_date'];
            $baptism_place = $row1['baptism_place'];
            $communion_date = $row1['communion_date'];
            $communion_place = $row1['communion_place'];
        }

	}else{
        header('location:communion.php');
		die();
	}
}

?>
<style>
    .table td, .table th {
        border: 0;
    }
    </style>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Communion Certificate</h4>
							</div>
							<div class="col-6 text-right">
                                <button class="btn btn-sm btn-success" id="print">Print</button>
								<a class="btn btn-sm btn-dark"  href="<?php echo 'communion.php' ?>">Back</a>
							</div>
						</div>	
					</div>
					<div  id="outprint">
                        <center><img src='images/logo.jpg' id='print-logo' /><center>
                        <div class='mx-5 pb-4'>
                            <h1 class='text-center mb-1'>Certificate of Communion</h1>
                            <h3 class='text-center mb-1'>St.joseph's Cathedral</h3>
                            <center><small class='text-muted'>Knh Road, Dindigul - 624001 (Near Municipal Office)</small></center>
                        </div>
                        <hr class='border-navy '>
                        <fieldset>
                            <div class="card-body card-block">
                                <div class="row">
                                    <div class="col-12">
                                        <table class="table " style="width: 700px; margin:0 auto;">
                                            <tbody>
                                                <tr>
                                                    <th style="border: 0;">Name</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $member_name ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Sex</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $gender ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Date of Birth</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $dob ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Place of Birth</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $birth_place ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Date of Baptism</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $baptism_date ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Place of Baptism</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $baptism_place ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Father's Name</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $father_name ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Mother's Name</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $mother_name ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Date of Communion</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $communion_date ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Place of Communion</th>
                                                    <td>:</td>
                                                    <td style="border: 0;"><?php echo $communion_place ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <div class="text-center">
                                <h4 class="font-weight-bold py-5">Seal</h4>
                        </div>
                        <div class="text-center">
                            <p class="font-weight-bold py-5">This is the true copy of the entry electronically generated</p>                        
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>