<?php
require('top.inc.php');
isAdmin();
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from confirmation_list where id='$id'";
		$delete_res = mysqli_query($con,$delete_sql); 
		if($delete_res) {
			header('location:confirmation.php');
			die();
		}
	}
}
if(isset($_POST['search'])){
	$family_no = isset($_POST['family_no']) ? get_safe_value($con, $_POST['family_no']) : '';
	$family_name = isset($_POST['family_name']) ? get_safe_value($con, $_POST['family_name']) : '';	$contact_number = isset($_POST['contact_number']) ? get_safe_value($con, $_POST['contact_number']) : '';	
	$substation = isset($_POST['substation']) ? get_safe_value($con, $_POST['substation']) : '';

	// Construct SQL query
    $sql = "SELECT id FROM families WHERE 1";
	if(!empty($family_no)) {
		$sql .= " AND family_no LIKE '%$family_no%'";
	}
	if(!empty($family_name)) {
		$sql .= " AND family_name LIKE '%$family_name%'";
	}
	if(!empty($contact_number)) {
		$sql .= " AND contact_number LIKE '%$contact_number%'";
	}
	if(!empty($substation)) {
		$sql .= " AND substation LIKE '%$substation%'";
	}

	$result = mysqli_query($con, $sql);

	// Fetch records and return as JSON
    $records = [];
	if ($result && mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$records[] = $row;
		}
	}

	$response_array = json_decode(json_encode($records), true); // Decode JSON string to an array

	if (!empty($response_array)) {
		$family_ids = array_map(function($item) {
			return $item['id'];
		}, $response_array);

		$family_ids_str = implode(',', $family_ids);
		$sql = "SELECT b.*, fm.member_name, fm.confirmation_date
		FROM confirmation_list AS b
		JOIN family_members AS fm ON b.member_id = fm.id
		WHERE b.family_id IN ($family_ids_str)
		ORDER BY b.id DESC";
		$res = mysqli_query($con, $sql);
		if (!$res) {
			// Query execution failed, handle the error
			die("Query failed: " . mysqli_error($con));
		}
	}

}else {
	$sql="SELECT b.*, fm.member_name, fm.confirmation_date
	FROM confirmation_list AS b
	JOIN family_members AS fm ON b.member_id = fm.id
	ORDER BY b.id DESC";
	$res=mysqli_query($con,$sql);
	if (!$res) {
		// Query execution failed, handle the error
		die("Query failed: " . mysqli_error($con));
	}
}
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
					<div class="accordion" id="accordionExample">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Confirmation Records</h4>
							</div>
							<div class="col-6 text-right">
									<button class="btn btn-sm btn-primary" data-toggle="collapse" data-target="#collapseGeneral" aria-expanded="true" aria-controls="collapseGeneral" ><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-filter" viewBox="0 0 16 16"><path d="M6 10.5a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5m-2-3a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5m-2-3a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11a.5.5 0 0 1-.5-.5"/></svg></button>
							</div>
							<div class="col-12">
								<div id="collapseGeneral" class="collapse" aria-labelledby="generalInformation" data-parent="#accordionExample">
									<form method="post" enctype="multipart/form-data">
										<div class="row mt-3">
											<div class="col-md-11">
												<div class="row">
													<div class="col-sm-3">
														<div class="form-group">
															<input type="text" class="form-control" id='familyNo' name='family_no' placeholder="Family card no" value="<?php echo isset($family_no)? $family_no : ''?>">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<input type="text" class="form-control" id='family_name' name='family_name' placeholder="Family name"  value="<?php echo isset($family_name) ? $family_name: ''?>">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<input type="text" class="form-control"  id='substation' name='substation'  placeholder="Substation" value="<?php echo isset($substation) ? $substation : '' ?>">
														</div>
													</div>
													<div class="col-sm-3">
														<div class="form-group">
															<input type="text" id="contactNumber" class="form-control"
															name="contact_number"
																placeholder="Contact number" value="<?php echo isset($contact_number) ? $contact_number : '' ?>" />
														</div>
													</div>
												</div>
											</div>
											<div class="col-md-1">
												<button class="btn btn-sm btn-success" name="search" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/></svg></button>
											</div>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				
				   <div class="table-stats order-table ov-h">
					  <table class="table" id="tbl_families">
						 <thead>
							<tr>
                                <th>S.No</th>
                                <th>Date Created</th>
								<th>Name</th>
								<th>Date confirmation</th>
                                <th>Action</th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							if(isset($res)) {
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td class="serial"><?php echo $i++; ?></td>
							   <td><?php echo $row['created_at']?></td>
							   <td><?php echo $row['member_name']?></td>
							   <td><?php echo $row['confirmation_date']?></td>

							   <td>
								<?php

                                    echo "<span class='badge badge-info'><a href='confirmation_view.php?type=view&id=".$row['id']."'>View / Print</a></span>&nbsp;";
                                    
                                    echo "<span class='badge badge-secondary'><a href='confirmation_manage.php?member_id=".$row['member_id']."&id=".$row['id']."'>Edit</a></span>&nbsp;";
                                    
                                    echo "<span class='badge badge-danger'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>";
                                    
								?>
							   </td>
							</tr>
							<?php } }?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
