<?php
require('top.inc.php');
$family_id = "";
$member_id = "";
if(isset($_GET['member_id']) && $_GET['member_id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['member_id']);
	$res=mysqli_query($con,"select * from family_members where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$family_id = $row['family_id'];
		$member_id = $row['id'];
		$member_name = $row['member_name'];
		$gender = $row['gender'];
		$birth_place = $row['birth_place'];
		$confirmation_date = $row['confirmation_date'];
		$confirmation_place = $row['confirmation_place'];
        $communion_date = $row['communion_date'];
        $communion_place = $row['communion_place'];

        $confirmation_res=mysqli_query($con,"select * from confirmation_list where member_id='$id'");
		$result = mysqli_num_rows($confirmation_res);

		if($result > 0) {
			$row1=mysqli_fetch_assoc($confirmation_res);
			$father_name = $row1['father_name'];
			$mother_name = $row1['mother_name'];
		}
	}else{
		header('location:baptism.php');
		die();
	}
}
if(isset($_POST['submit'])){
	$family_id = $family_id;
	$member_id = $member_id ;
	$father_name = get_safe_value($con, $_POST['father_name']);
	$mother_name = get_safe_value($con, $_POST['mother_name']);
	$created_at = date("Y/m/d");

	if(isset($_GET['id']) && $_GET['id']!=''){
		$id = $_GET['id'];
		$update_sql="UPDATE confirmation_list SET 
		family_id ='$family_id',
		member_id = '$member_id',
        father_name = '$father_name',
        mother_name = '$mother_name'
        WHERE id = '$id'";
		// Execute the update query
		if(mysqli_query($con, $update_sql)) {
			header('location:confirmation.php');
			die();
		} else {
			echo "Error updating record: " . mysqli_error($con);
		}

	}else{
		$res = mysqli_query($con, "INSERT INTO confirmation_list (family_id, member_id, father_name, mother_name, created_at) VALUES ('$family_id', '$member_id', '$father_name', '$mother_name', '$created_at')");

		if($res) {
			header('location:confirmation.php');
			die();
		}else {
			echo "Error: " . mysqli_error($con);
		}
	}
}
?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Confirmation Form</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="confirmation.php" >Back</a>
							</div>
						</div>	
					</div>
					<form method="post" enctype="multipart/form-data">
						<div class="card-body card-block">
                            <div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Communion Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
							    <div class="col-sm-4">
									<div class="form-group">
										<label for="communionDate">Communion Date</label>
										<input type="date"  class="form-control" disabled placeholder="" id="communionDate" name="communion_date" value="<?php echo isset($communion_date) ? $communion_date : '' ?>" />
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="communionPlace">Communion Place</label>
										<input type="text"  class="form-control" disabled id="communionPlace"   name="communion_place" value="<?php echo isset($communion_place) ? $communion_place : '' ?>"  placeholder="Enter communion place" />
										
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Confirmation Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
							    <div class="col-sm-4">
									<div class="form-group">
										<label for="confirmationDate">Confirmation Date</label>
										<input type="date"  class="form-control" disabled placeholder="" id="confirmationDate" name="confirmation_date" value="<?php echo isset($confirmation_date) ? $confirmation_date : '' ?>" />
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="confirmationPlace">Confirmation Place</label>
										<input type="text"  class="form-control" disabled id="confirmationPlace"   name="confirmation_place" value="<?php echo isset($confirmation_place) ? $confirmation_place : '' ?>"  placeholder="Enter confirmation place" />
										
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Member Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="memberName">Member Name</label>
										<input type="text" id="memberName" disabled class="form-control" placeholder="Enter member name" name="member_name" value="<?php echo isset($member_name) ? $member_name : '' ?>" />
									</div>
								</div>
							
								<div class="col-sm-4">
									<div class="form-group">
										<label for="gender">Gender</label>
										<select class="form-control" disabled id="gender" name="gender" aria-label="">
											<option value="">Select Gender</option>
											<option value="Male" <?php echo isset($gender) && $gender == 'Male' ? 'selected': '' ?>>Male</option>
											<option value="Female" <?php echo isset($gender) && $gender == 'Female' ? 'selected': '' ?>>Female</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="dob">Date of Birth</label>
										<input type="date" id="dob" class="form-control" name="dob"  placeholder=""  disabled value="<?php echo isset($dob) ? $dob : '' ?>" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Parent's Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="father_name">Father Name</label>
										<input type="text" id="father_name" class="form-control" placeholder="Enter father name" name="father_name" value="<?php echo isset($father_name) ? $father_name : '' ?>" />
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="mother_name">Mother Name</label>
										<input type="text" id="mother_name" class="form-control" placeholder="Enter mother name" name="mother_name" value="<?php echo isset($mother_name) ? $mother_name : '' ?>" />
									</div>
								</div>
							</div>
							<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block">
							<span>SUBMIT</span>
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
