-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 03, 2024 at 12:40 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chruch_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `role`, `email`, `mobile`, `status`) VALUES
(1, 'Admin', '1234', 0, 'admin@gmail.com', '12345678910', 1);

-- --------------------------------------------------------

--
-- Table structure for table `baptismal_list`
--

CREATE TABLE `baptismal_list` (
  `id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `father_name` varchar(200) NOT NULL,
  `mother_name` varchar(200) NOT NULL,
  `residence` text NOT NULL,
  `god_father` varchar(200) NOT NULL,
  `god_mother` varchar(200) NOT NULL,
  `minister_of_baptism` varchar(200) NOT NULL,
  `created_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `baptismal_list`
--

INSERT INTO `baptismal_list` (`id`, `family_id`, `member_id`, `father_name`, `mother_name`, `residence`, `god_father`, `god_mother`, `minister_of_baptism`, `created_at`) VALUES
(1, 1, 1, 'John', 'Delsi', '123 Main Street, Anytown, USA 12345', 'Doe', 'Doe1', 'Rosy', '2024-04-03'),
(2, 1, 4, 'XXX', 'werwyy', '123 Main Street, Anytown, USA 12345', 'sadh', 'BBB', 'geetha', '2024-04-03');

-- --------------------------------------------------------

--
-- Table structure for table `communion_list`
--

CREATE TABLE `communion_list` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `father_name` varchar(150) NOT NULL,
  `mother_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `communion_list`
--

INSERT INTO `communion_list` (`id`, `member_id`, `family_id`, `created_at`, `father_name`, `mother_name`) VALUES
(1, 2, 1, '2024-04-03', 'XXX', 'YYY');

-- --------------------------------------------------------

--
-- Table structure for table `confirmation_list`
--

CREATE TABLE `confirmation_list` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `father_name` varchar(150) NOT NULL,
  `mother_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `confirmation_list`
--

INSERT INTO `confirmation_list` (`id`, `member_id`, `family_id`, `created_at`, `father_name`, `mother_name`) VALUES
(1, 4, 1, '2024-04-03', 'XXX', 'werwyy');

-- --------------------------------------------------------

--
-- Table structure for table `death_list`
--

CREATE TABLE `death_list` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `age` varchar(50) NOT NULL,
  `created_at` date NOT NULL,
  `parents_name` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `burial_date` date DEFAULT NULL,
  `burial_place` varchar(200) NOT NULL,
  `minister` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `death_list`
--

INSERT INTO `death_list` (`id`, `member_id`, `family_id`, `age`, `created_at`, `parents_name`, `address`, `burial_date`, `burial_place`, `minister`) VALUES
(1, 3, 1, '27', '2024-04-03', 'CCC', '123 Main Street, Anytown, USA 12345', '2024-04-06', 'Dindigul', 'Geetha');

-- --------------------------------------------------------

--
-- Table structure for table `families`
--

CREATE TABLE `families` (
  `id` int(11) NOT NULL,
  `family_no` varchar(50) DEFAULT NULL,
  `anbiyam` varchar(50) DEFAULT NULL,
  `family_name` varchar(255) DEFAULT NULL,
  `substation` varchar(100) DEFAULT NULL,
  `native` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `whatsapp_number` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `subscription` varchar(150) DEFAULT NULL,
  `cemetery` tinyint(4) NOT NULL DEFAULT 0,
  `house` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `families`
--

INSERT INTO `families` (`id`, `family_no`, `anbiyam`, `family_name`, `substation`, `native`, `contact_number`, `whatsapp_number`, `address`, `subscription`, `cemetery`, `house`, `created_at`) VALUES
(1, 'FC-01', 'Francis Xavier', 'Viniba Family', 'CATHEDRAL', 'Dindigul', '6380546789', '6543234567', '123 Main Street, Anytown, USA 12345', '100', 1, 'Own', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `families_old`
--

CREATE TABLE `families_old` (
  `id` int(11) NOT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `family_no` varchar(50) DEFAULT NULL,
  `relationship` varchar(100) DEFAULT NULL,
  `anbiyam` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `family_name` varchar(255) DEFAULT NULL,
  `substation` varchar(100) DEFAULT NULL,
  `native` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `birth_place` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `baptism` tinyint(1) DEFAULT NULL,
  `baptism_date` date DEFAULT NULL,
  `baptism_place` varchar(100) DEFAULT NULL,
  `communion` tinyint(1) DEFAULT NULL,
  `communion_date` date DEFAULT NULL,
  `communion_place` varchar(100) DEFAULT NULL,
  `confirmation` tinyint(1) NOT NULL,
  `confirmation_date` date DEFAULT NULL,
  `confirmation_place` varchar(100) NOT NULL,
  `married` tinyint(1) DEFAULT NULL,
  `married_date` date DEFAULT NULL,
  `married_place` varchar(100) DEFAULT NULL,
  `alive` tinyint(1) DEFAULT NULL,
  `death_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `family_members`
--

CREATE TABLE `family_members` (
  `id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `birth_place` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `baptism` tinyint(1) DEFAULT NULL,
  `baptism_date` date DEFAULT NULL,
  `baptism_place` varchar(100) DEFAULT NULL,
  `communion` tinyint(1) DEFAULT NULL,
  `communion_date` date DEFAULT NULL,
  `communion_place` varchar(100) DEFAULT NULL,
  `confirmation` tinyint(1) DEFAULT NULL,
  `confirmation_date` date DEFAULT NULL,
  `confirmation_place` varchar(100) DEFAULT NULL,
  `married` tinyint(1) DEFAULT NULL,
  `married_date` date DEFAULT NULL,
  `married_place` varchar(100) DEFAULT NULL,
  `alive` tinyint(1) DEFAULT NULL,
  `death_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `family_members`
--

INSERT INTO `family_members` (`id`, `family_id`, `member_name`, `gender`, `relationship`, `dob`, `birth_place`, `qualification`, `occupation`, `baptism`, `baptism_date`, `baptism_place`, `communion`, `communion_date`, `communion_place`, `confirmation`, `confirmation_date`, `confirmation_place`, `married`, `married_date`, `married_place`, `alive`, `death_date`) VALUES
(1, 1, 'Viniba', 'Female', 'FamilyHead', '2024-04-05', 'Dindigul', 'BCA', 'XXX', 1, '2024-04-01', 'Dindigul', 1, '2024-04-03', 'Dindigul', 1, '2024-04-01', 'Dindigul', 1, '2024-04-02', 'Dindigul', 1, '0000-00-00'),
(2, 1, 'Priya', 'Female', 'Mother', '2024-04-06', 'Dindigul', 'BCA', 'CCCC', 1, '2024-04-26', 'Dindigul', 1, '2024-04-04', 'Dindigul', 1, '2024-04-02', 'Dindigul', 1, '2024-04-20', 'SDGASDG', 1, '0000-00-00'),
(3, 1, 'Death', 'Male', 'Others', '2024-04-04', 'Dindigul', 'BE', 'VVV', 0, '0000-00-00', '', 0, '0000-00-00', '', 0, '0000-00-00', '', 0, '0000-00-00', '', 0, '2024-04-21'),
(4, 1, 'Confirmation', 'Male', 'Son', '2024-04-13', 'Dindigul', 'BSC', 'GGG', 1, '2024-04-18', 'Dindigul', 1, '2024-04-06', 'Dindigul', 1, '2024-04-25', 'Dindigul', 0, '0000-00-00', '', 1, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `married_list`
--

CREATE TABLE `married_list` (
  `id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `bridegroom_name` varchar(200) NOT NULL,
  `bridegroom_marital_status` varchar(100) NOT NULL,
  `bridegroom_domicile` varchar(200) NOT NULL,
  `bridegroom_age` int(11) NOT NULL,
  `bridegroom_father` varchar(150) NOT NULL,
  `bridegroom_mother` varchar(150) NOT NULL,
  `bride_name` varchar(150) NOT NULL,
  `bride_marital_status` varchar(150) NOT NULL,
  `bride_age` int(11) NOT NULL,
  `bride_domicile` varchar(200) NOT NULL,
  `bride_father` varchar(150) NOT NULL,
  `bride_mother` varchar(150) NOT NULL,
  `witness1` varchar(255) NOT NULL,
  `witness2` varchar(255) NOT NULL,
  `minister` varchar(255) NOT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `married_list`
--

INSERT INTO `married_list` (`id`, `family_id`, `member_id`, `bridegroom_name`, `bridegroom_marital_status`, `bridegroom_domicile`, `bridegroom_age`, `bridegroom_father`, `bridegroom_mother`, `bride_name`, `bride_marital_status`, `bride_age`, `bride_domicile`, `bride_father`, `bride_mother`, `witness1`, `witness2`, `minister`, `created_at`) VALUES
(1, 1, 1, 'XXX', 'Bachelor', 'XXX', 30, 'XXX', 'YYY', 'Geetha', 'Spinster', 29, 'CCC', 'CCCC1', 'VVV1', 'CC', 'fsdhh', 'Geetha', '2024-04-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `baptismal_list`
--
ALTER TABLE `baptismal_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `communion_list`
--
ALTER TABLE `communion_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `confirmation_list`
--
ALTER TABLE `confirmation_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `death_list`
--
ALTER TABLE `death_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `families_old`
--
ALTER TABLE `families_old`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `family_members`
--
ALTER TABLE `family_members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `married_list`
--
ALTER TABLE `married_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `baptismal_list`
--
ALTER TABLE `baptismal_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `communion_list`
--
ALTER TABLE `communion_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `confirmation_list`
--
ALTER TABLE `confirmation_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `death_list`
--
ALTER TABLE `death_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `families`
--
ALTER TABLE `families`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `families_old`
--
ALTER TABLE `families_old`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `family_members`
--
ALTER TABLE `family_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `married_list`
--
ALTER TABLE `married_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
