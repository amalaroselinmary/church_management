<?php
require('top.inc.php');
$family_id = "";
$member_id = "";
if(isset($_GET['member_id']) && $_GET['member_id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['member_id']);
	$res=mysqli_query($con,"select * from family_members where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$family_id = $row['family_id'];
		$member_id = $row['id'];
		$member_name = $row['member_name'];
		$gender = $row['gender'];
		$death_date = $row['death_date'];
		$death_res=mysqli_query($con,"select * from death_list where member_id='$id'");
		$result = mysqli_num_rows($death_res);

		if($result > 0) {
			$row1=mysqli_fetch_assoc($death_res);
			$parents_name = $row1['parents_name'];
			$age = $row1['age'];
			$address = $row1['address'];
			$burial_date = $row1['burial_date'];
			$minister = $row1['minister'];
			$burial_place = $row1['burial_place'];
		}
	}else{
		header('location:death.php');
		die();
	}
}
if(isset($_POST['submit'])){
	$family_id = $family_id;
	$member_id = $member_id ;
	$minister_of_death = get_safe_value($con, $_POST['minister']);
	$burial_place = get_safe_value($con, $_POST['burial_place']);
	$burial_date = get_safe_value($con, $_POST['burial_date']);
	$parents_name = get_safe_value($con, $_POST['parents_name']);
	$age = get_safe_value($con, $_POST['age']);
	$address = get_safe_value($con, $_POST['address']);
	$created_at = date("Y/m/d");

	if(isset($_GET['id']) && $_GET['id']!=''){
		$id = $_GET['id'];
		$update_sql="UPDATE death_list SET 
		family_id ='$family_id',
		member_id = '$member_id',
        age = '$age',
        parents_name = '$parents_name',
        address = '$address',
        burial_date = '$burial_date',
        burial_place = '$burial_place',
        minister = '$minister_of_death'
        WHERE id = '$id'";
		// Execute the update query
		if(mysqli_query($con, $update_sql)) {
			header('location:death.php');
			die();
		} else {
			echo "Error updating record: " . mysqli_error($con);
		}

	}else{
		$res = mysqli_query($con, "INSERT INTO death_list (family_id, member_id, age, parents_name,address, burial_date, burial_place, minister, created_at) VALUES ('$family_id', '$member_id', '$age', '$parents_name', '$address', '$burial_date','$burial_place', '$minister_of_death','$created_at')");

		if($res) {
			header('location:death.php');
			die();
		}else {
			echo "Error: " . mysqli_error($con);
		}
	}
}
?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Death Form</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="death.php" >Back</a>
							</div>
						</div>	
					</div>
					<form method="post" enctype="multipart/form-data">
						<div class="card-body card-block">
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Death Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
							<div class="col-sm-4">
									<div class="form-group">
										<label for="deathDate">Death Date</label>
										<input type="date"  class="form-control" disabled placeholder="" id="deathDate" name="death_date" value="<?php echo isset($death_date) ? $death_date : '' ?>" />
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="burial_date">Burial Date</label>
										<input type="date"  class="form-control" id="burial_date"   name="burial_date" value="<?php echo isset($burial_date) ? $burial_date : '' ?>"  placeholder="Enter burial date" />
										
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="burial_place">Burial Place</label>
										<input type="text"  class="form-control" id="burial_place"   name="burial_place" value="<?php echo isset($burial_place) ? $burial_place : '' ?>"  placeholder="Enter burial place" />
										
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="minister">Minister</label>
										<input type="text" id="minister" class="form-control" placeholder="Enter minister name" name="minister" value="<?php echo isset($minister_of_death) ? $minister_of_death  : '' ?>" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Baptizee's Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="memberName">Member Name</label>
										<input type="text" id="memberName" disabled class="form-control" placeholder="Enter member name" name="member_name" value="<?php echo isset($member_name) ? $member_name : '' ?>" />
									</div>
								</div>
							
								<div class="col-sm-4">
									<div class="form-group">
										<label for="gender">Gender</label>
										<select class="form-control" disabled id="gender" name="gender" aria-label="">
											<option value="">Select Gender</option>
											<option value="Male" <?php echo isset($gender) && $gender == 'Male' ? 'selected': '' ?>>Male</option>
											<option value="Female" <?php echo isset($gender) && $gender == 'Female' ? 'selected': '' ?>>Female</option>
										</select>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="dob">Date of Birth</label>
										<input type="date" id="dob" class="form-control" name="dob"  placeholder=""  disabled value="<?php echo isset($dob) ? $dob : '' ?>" />
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="birthPlace">Birth Place</label>
										<input type="text" id="birthPlace" class="form-control"
										name="birth_place"
											placeholder="Enter birth place" disabled value="<?php echo isset($birth_place) ? $birth_place : '' ?>" />
									</div>
								</div> 
								<div class="col-sm-4">
									<div class="form-group">
										<label for="age">Age</label>
										<input type="text" id="age" class="form-control"
										name="age"
											placeholder="Enter age" value="<?php echo isset($age) ? $age : '' ?>" />
									</div>
								</div> 
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Parent's Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="parents_name">Parents Name</label>
										<input type="text" id="parents_name" class="form-control" placeholder="Enter father name" name="parents_name" value="<?php echo isset($parents_name) ? $parents_name : '' ?>" />
									</div>
								</div>
								<div class="col-sm-12">
									<div class="form-group">
										<label for="address">Address</label>
										<textarea class="form-control" id="address" name="address" placeholder=""><?php echo isset($address) ? $address : '' ?></textarea>
									</div>
								</div>  
							</div>
							
							<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block">
							<span>SUBMIT</span>
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
