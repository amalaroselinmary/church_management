<?php
require('top.inc.php');
isAdmin();
$errorMessage = isset($_GET['error']) ? urldecode($_GET['error']) : '';

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$members_res=mysqli_query($con,"select * from family_members where family_id='$id'");
		$check=mysqli_num_rows($members_res);
		if($check>0){
			$msg = "Cannot delete family because there are $check members attached to it."; // Specify your header text here
			$error = urlencode($msg);
			header('location:families.php?error='.$error);
			die();
		}
		$delete_sql="delete from families where id='$id'";
		$delete_res = mysqli_query($con,$delete_sql); 
		if($delete_res) {
			header('location:families.php');
			die();
		}
	}
}

$sql="SELECT f.*, fm.member_name FROM families f LEFT JOIN (
									SELECT *
									FROM family_members
									WHERE relationship = 'FamilyHead'
								) fm ON f.id = fm.family_id ORDER BY f.id DESC";
$res=mysqli_query($con,$sql);
if (!$res) {
    // Query execution failed, handle the error
    die("Query failed: " . mysqli_error($con));
}
?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
					<div class="row">
						<div class="col-6">
							<h4 class="box-title">Families</h4>
						</div>
						<div class="col-6 text-right">
							<a class="btn btn-sm btn-primary" href="families_manage.php">ADD New</a>
							<a class="btn btn-sm btn-secondary ml-3" href="importdataexcel.php">Import</a>
						</div>
						<?php if($errorMessage != '') { ?>
								<div class="col-12 pt-2">
									<div class="alert alert-danger alert-dismissible" role="alert"><?php echo $errorMessage; ?>
									<button type="button" class="close" data-dismiss="alert">&times;</button></div>
								</div>
						<?php } ?>
					</div>
				
				   <div class="table-stats order-table ov-h">
					  <table class="table" id="tbl_families">
						 <thead>
							<tr>
                                <th>S.No</th>
                                <th>Family Card No</th>
								<th>Family Head</th>
								<th>Contact Number</th>
                                <th>Action</th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td class="serial"><?php echo $i++; ?></td>
							   <td><?php echo $row['family_no']?></td>
							   <td><?php echo $row['member_name']?></td>
							   <td><?php echo $row['contact_number']?></td>
							   <td>
								<?php

                                    echo "<span class='badge badge-info'><a href='families_view.php?type=view&id=".$row['id']."'>View</a></span>&nbsp;";
                                    
                                    echo "<span class='badge badge-secondary'><a href='families_manage.php?id=".$row['id']."'>Edit</a></span>&nbsp;";
                                    
                                    echo "<span class='badge badge-danger'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>&nbsp;";

									echo "<span class='badge badge-primary'><a href='members_manage.php?family_id=".$row['id']."'>Add Members</a></span>&nbsp;";
                                    
								?>
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
