<?php
require('top.inc.php');
isAdmin();
$msg='';
$family_id = '';
$member_show = true;
$alive = 1;


$s_res=mysqli_query($con,"select * from substations");
$check=mysqli_num_rows($s_res);


if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$member_show = false;
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from families where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$family_id = $row['id'];
		$family_no = $row['family_no'];
		$anbiyam = $row['anbiyam'];
		$family_name = $row['family_name'];
		$substation = $row['substation'];
		$native = $row['native'];
		$contact_number = $row['contact_number'];
		$whatsapp_number = $row['whatsapp_number'];
		$subscription = $row['subscription'];
		$cemetery = $row['cemetery'];
		$house = $row['house'];
		$address = $row['address'];
	}else{
		header('location:families.php');
		die();
	}
}


if(isset($_POST['submit'])){
	
	$member_name = isset($_POST['member_name']) ? get_safe_value($con, $_POST['member_name']) : '';
	$family_no = isset($_POST['family_no']) ? get_safe_value($con, $_POST['family_no']) : '';
	$anbiyam = isset($_POST['anbiyam']) ? get_safe_value($con, $_POST['anbiyam']) : '';
	$gender = isset($_POST['gender']) ? get_safe_value($con, $_POST['gender']) : '';
	$family_name = isset($_POST['family_name']) ? get_safe_value($con, $_POST['family_name']) : '';
	$substation = isset($_POST['substation']) ? get_safe_value($con, $_POST['substation']) : '';
	$native = isset($_POST['native']) ? get_safe_value($con, $_POST['native']) : '';
	$contact_number = isset($_POST['contact_number']) ? get_safe_value($con, $_POST['contact_number']) : '';
	$whatsapp_number = isset($_POST['whatsapp_number']) ? get_safe_value($con, $_POST['whatsapp_number']) : '';
	$dob = isset($_POST['dob']) ? get_safe_value($con, $_POST['dob']) : '';
	$birth_place = isset($_POST['birth_place']) ? get_safe_value($con, $_POST['birth_place']) : '';
	$qualification = isset($_POST['qualification']) ? get_safe_value($con, $_POST['qualification']) : '';
	$occupation = isset($_POST['occupation']) ? get_safe_value($con, $_POST['occupation']) : '';
	$subscription = isset($_POST['subscription']) ? get_safe_value($con, $_POST['subscription']) : '';
	$address = isset($_POST['address']) ? get_safe_value($con, $_POST['address']) : '';
	$baptism = isset($_POST['baptism']) ? get_safe_value($con, isset($_POST['baptism']) ? 1 : 0) : 0;
	$baptism_date = isset($_POST['baptism_date']) ? get_safe_value($con, $_POST['baptism_date']) : '';
	$baptism_place = isset($_POST['baptism_place']) ? get_safe_value($con, $_POST['baptism_place']) : '';
	$communion = isset($_POST['communion']) ? get_safe_value($con, isset($_POST['communion']) ? 1 : 0) : 0;
	$communion_date = isset($_POST['communion_date']) ? get_safe_value($con, $_POST['communion_date']) : '';
	$communion_place = isset($_POST['communion_place']) ? get_safe_value($con, $_POST['communion_place']) : '';
	$confirmation = isset($_POST['confirmation']) ? get_safe_value($con, isset($_POST['confirmation']) ? 1 : 0) : 0;
	$confirmation_date = isset($_POST['confirmation_date']) ? get_safe_value($con, $_POST['confirmation_date']) : '';
	$confirmation_place = isset($_POST['confirmation_place']) ? get_safe_value($con, $_POST['confirmation_place']) : '';
	$married = isset($_POST['married']) ? get_safe_value($con, isset($_POST['married']) ? 1 : 0) : 0;
	$married_date = isset($_POST['married_date']) ? get_safe_value($con, $_POST['married_date']) : '';
	$married_place = isset($_POST['married_place']) ? get_safe_value($con, $_POST['married_place']) : '';
	$alive = isset($_POST['alive']) ? get_safe_value($con, isset($_POST['alive']) ? 1 : 0) : 0;
	$death_date = isset($_POST['death_date']) ? get_safe_value($con, $_POST['death_date']) : '';
	$created_at =  date("Y/m/d");
	$relationship = isset($_POST['relationship']) ? get_safe_value($con, $_POST['relationship']) : '';
	$cemetery = isset($_POST['cemetery']) ? get_safe_value($con, isset($_POST['cemetery']) ? 1 : 0) : 0;
	$house = isset($_POST['house']) ? get_safe_value($con, $_POST['house']) : '';

	if(isset($_GET['id']) && $_GET['id']!=''){
		$update_sql="UPDATE families SET 
        family_no = '$family_no',
        anbiyam = '$anbiyam',
        family_name = '$family_name',
        substation = '$substation',
        native = '$native',
        contact_number = '$contact_number',
		whatsapp_number = '$whatsapp_number',
		subscription = '$subscription',
        address = '$address',
		cemetery = '$cemetery',
		house = '$house'
        WHERE id = '$id'";
		// Execute the update query
		if(mysqli_query($con, $update_sql)) {
			header('location:families.php');
			die();
		} else {
			echo "Error updating record: " . mysqli_error($con);
		}

	}else{
		$res = mysqli_query($con, "INSERT INTO families (family_no, anbiyam, family_name, substation, native, contact_number, whatsapp_number, address, subscription, cemetery, house, created_at) VALUES ('$family_no',  '$anbiyam', '$family_name', '$substation', '$native', '$contact_number', '$whatsapp_number','$address', '$subscription', '$cemetery', '$house', $created_at)");

		if($res) {
			$inserted_id = mysqli_insert_id($con);

			$member_res = mysqli_query($con, "INSERT INTO family_members (family_id, member_name, gender, relationship, dob, birth_place, qualification, occupation, baptism, baptism_date, baptism_place, communion, communion_date, communion_place, confirmation, confirmation_date, confirmation_place, married, married_date, married_place, alive, death_date) VALUES ('$inserted_id', '$member_name', '$gender', '$relationship', '$dob', '$birth_place', '$qualification', '$occupation', '$baptism', '$baptism_date', '$baptism_place', '$communion', '$communion_date', '$communion_place', '$confirmation', '$confirmation_date', '$confirmation_place', '$married', '$married_date', '$married_place', '$alive', '$death_date')");
			if($member_res) {
				header('location:families.php');
				die();
			}else {
				echo "Error: " . mysqli_error($con);
			}

		}else {
			echo "Error: " . mysqli_error($con);
		}
	}
}
?>

<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Member FORM</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="families.php">Back</a>
							</div>
						</div>	
					</div>
					<form method="post" id="family_form" enctype="multipart/form-data">
						<div class="accordion" id="accordionExample">
							<div class="card-body card-block">
								<div class="row"> 
									<div class="col-12">
										<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0 accordion-button" type="button" data-toggle="collapse" data-target="#collapseFamily" aria-expanded="true" aria-controls="collapseFamily">Family Details</button>
										<hr />
									</div>
								</div>
								<div id="collapseFamily" class="collapse show accordion-item" aria-labelledby="familyDetails" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<label for="family_no">Family Card No</label>
												<input type="text" class="form-control" id='family_no' name='family_no' placeholder="Enter Family no" value="<?php echo isset($family_no)? $family_no : ''?>">
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="family_name">Family Name</label>
												<input type="text" class="form-control" id='family_name' name='family_name' placeholder="Enter family name"  value="<?php echo isset($family_name) ? $family_name: ''?>">
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="anbiyam">Anbiyam</label>
												<input type="text"   class="form-control" id="anbiyam" name="anbiyam" placeholder="Enter anbiyam" value="<?php echo isset($anbiyam) ? $anbiyam : ''?>">
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="substation">Substation</label>
												<select class="form-control" id="substation"  name="substation" aria-label="">
												<option value="">Select Substation</option>
												<?php 
													while($station=mysqli_fetch_assoc($s_res)){?> ?>
													<option value="<?php echo $station['substation_name']; ?>" <?php echo isset($substation) && $substation == $station['substation_name'] ? 'selected': '' ?>><?php echo $station['substation_name']; ?></option>
												<?php } ?>
											</select>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="native">Native</label>
												<input type="text" class="form-control"  id='native' name='native' placeholder="Enter native" value="<?php echo isset($native)? $native : '' ?>">
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="contactNumber">Contact Number</label>
												<input type="text" id="contact_number" class="form-control"
												name="contact_number"
													placeholder="Enter contact number" value="<?php echo isset($contact_number) ? $contact_number : '' ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="contactNumber">WhatsApp Number</label>
												<input type="text" id="whatsapp_number" class="form-control"
												name="whatsapp_number"
													placeholder="Enter whatsapp number" value="<?php echo isset($whatsapp_number) ? $whatsapp_number : '' ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="subscription">Monthly Subscription</label>
												<input type="text"  class="form-control" id="subscription" 
												name="subscription" placeholder="Enter subscription" value="<?php echo isset($subscription) ? $subscription : '' ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="subscription">House</label>
												<select class="form-control" id="house"  name="house" aria-label="">
													<option value="">Select House</option>
													<option value="Own" <?php echo isset($house) && $house == 'Own' ? 'selected': '' ?>>Own</option>
													<option value="Rented" <?php echo isset($house) && $house == 'Rented' ? 'selected': '' ?>>Rented</option>
												</select>
											</div>
										</div>
										<div class="col-sm-4"> Cemetery
											<div class="form-check form-switch">
												<input type="checkbox" id="cemetery" name="cemetery" <?php echo isset($cemetery) && $cemetery == '1' ? 'checked': '' ?> data-toggle="toggle" data-size="xs"  data-on="Yes" data-off="No" data-onstyle="primary" data-offstyle="secondary">
											</div>
										</div>
										<div class="col-sm-12 mt-2">
											<div class="form-group">
												<label for="address">Address</label>
												<textarea class="form-control" id="address" name="address" placeholder=""><?php echo isset($address) ? $address : '' ?></textarea>
											</div>
										</div>  
									</div>
								</div>
								
								<?php if($member_show){ ?>
								<div class="row">
									<div class="col-12">
										<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0 accordion-button" type="button" data-toggle="collapse" data-target="#collapseMember" aria-expanded="true" aria-controls="collapseMember">Member Information(Head)</button>
										<hr />
									</div>
								</div>
								<div id="collapseMember" class="collapse accordion-item" aria-labelledby="memberDetails" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<label for="member_name">Member Name</label>
												<input type="text" id="member_name" class="form-control" placeholder="Enter member name" name="member_name" value="<?php echo isset($member_name) ? $member_name : ''?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="Roles">Role/Relationship</label>
												<select class="form-control" id="relationship"  name="relationship" aria-label="">
													<option value="">Select Relationship</option>
													<option value="FamilyHead" <?php echo isset($relationship) && $relationship == 'FamilyHead' ? 'selected': '' ?>>Family Head</option>
													<!-- <option value="Son" < ?php echo isset($relationship) && $relationship == 'Son' ? 'selected': '' ?>>Son</option>
													<option value="Daughter" < ?php echo isset($relationship) && $relationship == 'Daughter' ? 'selected': '' ?>>Daughter</option>
													<option value="Father" < ?php echo isset($relationship) && $relationship == 'Father' ? 'selected': '' ?>>Father</option>
													<option value="Mother" < ?php echo isset($relationship) && $relationship == 'Mother' ? 'selected': '' ?>>Mother</option>
													<option value="Others" < ?php echo isset($relationship) && $relationship == 'Others' ? 'selected': '' ?>>Others</option> -->
												</select>
												
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="gender">Gender</label>
												<select class="form-control" id="gender" name="gender" aria-label="">
													<option value="">Select Gender</option>
													<option value="Male" <?php echo isset($gender) && $gender == 'Male' ? 'selected': '' ?>>Male</option>
													<option value="Female" <?php echo isset($gender) && $gender == 'Female' ? 'selected': '' ?>>Female</option>
												</select>
											</div>
										</div>
									
										
										<div class="col-sm-4">
											<div class="form-group">
												<label for="dob">Date of Birth</label>
												<input type="date" id="dob" class="form-control" name="dob"  placeholder="" value="<?php echo isset($dob) ? $dob : ''?>" />
											</div>
										</div>
									
										<div class="col-sm-4">
											<div class="form-group">
												<label for="birth_place">Birth Place</label>
												<input type="text" id="birth_place" class="form-control"
												name="birth_place"
													placeholder="Enter birth place" value="<?php echo isset($birth_place) ? $birth_place : ''  ?>" />
											</div>
										</div> 
										<div class="col-sm-4">
											<div class="form-group">
												<label for="qualification">Qualification</label>
												<input type="text" id="qualification" class="form-control"
												name="qualification"
													placeholder="Enter qualification" value="<?php echo isset($qualification) ? $qualification : '' ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="occupation">Occupation</label>
												<input type="text"  class="form-control" id="occupation" 
												name="occupation" placeholder="Enter occupation" value="<?php echo isset($occupation) ? $occupation : '' ?>" />
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-12">
										<button class="btn btn-link btn-collapse btn-block text-left box-title text-primary p-0 accordion-button" type="button" data-toggle="collapse" data-target="#collapseSacraments" aria-expanded="true" aria-controls="collapseSacraments">Sacraments Information</button>
										<hr />
									</div>
								</div>
								<div id="collapseSacraments" class="collapse accordion-item" aria-labelledby="memberDetails" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<label for="baptism">Baptism (yes/No)?</label>
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="baptism" type="checkbox" id="baptism" name="baptism"  <?php echo isset($baptism) && $baptism == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group baptism-fields" style="display: <?php echo isset($baptism) && $baptism == '1' ? 'block' : 'none'; ?>">
												<label for="baptism_date">Baptism Date</label>
												<input type="date" class="form-control" placeholder="" id="baptism_date" name="baptism_date" value="<?php echo isset($baptism_date) ? $baptism_date : '' ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group  baptism-fields" style="display: <?php echo isset($baptism) && $baptism == '1' ? 'block' : 'none'; ?>">
												<label for="baptism_place">Baptism Place</label>
												<input type="text" class="form-control" id="baptism_place" name="baptism_place" value="<?php echo isset($baptism_place) ? $baptism_place : '' ?>" placeholder="Enter baptism place" />
											</div>
										</div>
									</div>

									<div class="row">
										<div class="col-sm-4">
											<label for="communion">Holy Communion?</label>
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="communion" type="checkbox" id="communion" 
												name="communion"  <?php echo isset($communion) && $communion == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group communion-fields" style="display: <?php echo isset($communion) && $communion == '1' ? 'block' : 'none'; ?>">
												<label for="communion_date">Communion Date</label>
												<input type="date"  class="form-control" placeholder="" id="communion_date" value="<?php echo isset($communion_date) ? $communion_date : '' ?>" name="communion_date"/>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group communion-fields" style="display: <?php echo isset($communion) && $communion == '1' ? 'block' : 'none'; ?>">
												<label for="communion_place">Communion Place</label>
												<input type="text"  class="form-control" id="communion_place"   name="communion_place" value="<?php echo isset($communion_place) ? $communion_place : '' ?>"   placeholder="Enter communion place" />
												
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-4">
											<label for="confirmation">Confirmation?</label>
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="confirmation" type="checkbox" id="confirmation" 
												name="confirmation"  <?php echo isset($confirmation) && $confirmation == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group confirmation-fields" style="display: <?php echo isset($confirmation) && $confirmation == '1' ? 'block' : 'none'; ?>">
												<label for="confirmation_date">Confirmation Date</label>
												<input type="date"  class="form-control" placeholder="" id="confirmation_date" value="<?php echo isset($confirmation_date) ? $confirmation_date : '' ?>" name="confirmation_date"/>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group confirmation-fields" style="display: <?php echo isset($confirmation) && $confirmation == '1' ? 'block' : 'none'; ?>">
												<label for="confirmation_place">Confirmation Place</label>
												<input type="text"  class="form-control" id="confirmation_place"   name="confirmation_place" value="<?php echo isset($confirmation_place) ?$confirmation_place : '' ?>"   placeholder="Enter confirmation place" />
												
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-4">
											Married?
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="married" type="checkbox" id="married" name="married"  <?php echo isset($married) && $married == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group married-fields" style="display: <?php echo isset($married) && $married == '1' ? 'block' : 'none'; ?>">
												<label for="married_date">Married Date</label>
												<input type="date"  class="form-control" placeholder="" id="married_date" value="<?php echo isset($married_date) ? $married_date : '' ?>" name="married_date"/>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group married-fields" style="display: <?php echo isset($married) && $married == '1' ? 'block' : 'none'; ?>">
												<label for="married_place">Married Place</label>
												<input type="text"  class="form-control" id="married_place"   name="married_place" value="<?php echo isset($married_place) ?$married_place : '' ?>"  placeholder="Enter married place" />
												
											</div>
										</div>
									</div>
									<div class="row">  
										<div class="col-lg-4"> Is Alive?
												<div class="form-check form-switch">
													<input class="form-check-input event-checkbox" data-event="alive" type="checkbox" checked id="alive"
													name="alive" <?php echo isset($alive) && $alive == '1' ? 'checked': '' ?>>
											</div>
										</div>
										<div class="col-sm-4">
										<div class="form-group alive-fields" style="display: <?php echo isset($alive) && $alive == 1 ? 'none' : 'block'; ?>">
											<label for="death_date">Date of Death</label>
											<input type="date" class="form-control" value="<?php echo isset($death_date) ? $death_date : ''; ?>" placeholder="" id="death_date" name="death_date" />
										</div>
									</div>

									</div>
								</div>
								<?php } ?>
								<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block">
								<span>SUBMIT</span>
								</button>
								<div class="field_error"><?php echo $msg?></div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>