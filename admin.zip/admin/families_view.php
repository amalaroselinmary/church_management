<?php
require('top.inc.php');
isAdmin();
$msg='';
$id= isset($_GET['id']) ? get_safe_value($con,$_GET['id']): "";
$family_id = $id;

if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='member_delete'){
		$member_id=get_safe_value($con,$_GET['member_id']);
		$delete_sql="delete from family_members where id='$member_id'";
		$delete_res = mysqli_query($con,$delete_sql); 
		if($delete_res) {
			header('location:families_view.php?type=view&id='. $id);
			die();
		}
	}
}
if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from families where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$family_id = $id;
		$family_no = $row['family_no'];
		$anbiyam = $row['anbiyam'];
		$family_name = $row['family_name'];
		$substation = $row['substation'];
		$native = $row['native'];
		$contact_number = $row['contact_number'];
		$whatsapp_number = $row['whatsapp_number'];
		$address = $row['address'];
		$subscription = $row['subscription'];
		$house = $row['house'];
		$cemetery = $row['cemetery'];
		

		$members_res=mysqli_query($con,"select * from family_members where family_id='$id'");

	}else{
		header('location:families.php');
		die();
	}
}

?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Families View</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="families.php">Back</a>
							</div>
						</div>	
					</div>
					<form method="post" enctype="multipart/form-data">
						<div class="accordion" id="accordionExample">
							<div class="card-body card-block">
								<div class="row">
									<div class="col-12">
									<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0" type="button" data-toggle="collapse" data-target="#collapseFamily" aria-expanded="true" aria-controls="collapseFamily">Family Details</button>
									</div>
								</div>
								<hr>
								<div id="collapseFamily" class="collapse show" aria-labelledby="familyDetails" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="familyNo">Family Card No</label>
												<p> <?php echo $family_no?> </p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="familyname">Family Name</label>
												<p><?php echo isset($family_name) ?  $family_name : '' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="anbiyam">Anbiyam</label>
												<p> <?php echo isset($anbiyam) ? $anbiyam : '' ?> </p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="substation">Substation</label>
												<p><?php echo isset($substation) ? $substation : '' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="native">Native</label>
												<p><?php echo isset($native) ? $native : '' ?></p>
											</div>
										</div>
									
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="contactNumber">Contact Number</label>
												<p><?php echo isset($contact_number) ? $contact_number : '' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="whatsappNumber">WhatsApp Number</label>
												<p><?php echo isset($whatsapp_number) ? $whatsapp_number : '' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="subscription">Monthly Subscription</label>
												<p><?php echo isset($subscription) ? $subscription : '' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="subscription">House</label>
												<p><?php echo isset($house) ? $house : '' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="subscription">Cemetery</label>
												<p><?php echo isset($cemetery) && $cemetery ? 'Yes' : 'No' ?></p>
											</div>
										</div>
									</div>
									<div class="row">  
										<div class="col-sm-12">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="address">Address</label>
												<p><?php echo isset($address) ? $address : '' ?><p>
											</div>
										</div>  
									</div>
								</div>
								<div class="row">
									<div class="col-6">
										<h4 class="text-primary box-title">Members Details</h4>
									</div>
									<div class="col-6 text-right">
										<a class="btn btn-sm btn-primary" href="<?php echo 'members_manage.php?&family_id='. $family_id ?>">ADD Members</a>
									</div>
								</div>
								<hr />
								<div class="row">
									<div class="col-12">
										<div class="table-stats order-table ov-h">
											<table class="table" id="tbl_members">
												<thead>
													<tr>
														<th>S.No</th>
														<th>Member Name</th>
														<th>Relationship</th>
														<th>Gender</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<?php
													if(isset($members_res)){ 
													$i=1;
													while($row=mysqli_fetch_assoc($members_res)){?>
													<tr>
													<td class="serial"><?php echo $i++; ?></td>
													<td><?php echo $row['member_name']?></td>
													<td><?php echo $row['relationship']?></td>
													<td><?php echo $row['gender']?></td>
													<td>
														<?php

															echo "<span class='badge badge-info'><a href='members_view.php?type=view&family_id=".$family_id."&id=".$row['id']."'>View</a></span>&nbsp;";
															
															echo "<span class='badge badge-secondary'><a href='members_manage.php?family_id=". $family_id ."&id=".$row['id']."'>Edit</a></span>&nbsp;";
															
															echo "<span class='badge badge-danger'><a href='?id=". $family_id ."&type=member_delete&member_id=".$row['id']."'>Delete</a></span>";
															
														?>
													</td>
													</tr>
													<?php }} ?>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>