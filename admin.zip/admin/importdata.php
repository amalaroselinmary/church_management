<?php
include 'connection.inc.php';
    if(isset($_POST["Import"])){
        $filename=$_FILES["file"]["tmp_name"];
        $startAtLine = 0;
        $counter = 0;
        $countFirstRow = false;
        if($_FILES["file"]["size"] > 0)
        {
            $handle  = fopen($filename, "r");
            fgetcsv($handle);
            while ($data = fgetcsv($handle,1000,",","'"))
            {        
                    $family_no = $data[1];
                    $anbiyam = $data[2];
                    $family_name = $data[3];
                    $substation = $data[4];
                    $native = $data[5];
                    $contact_number = $data[6];
                    $address = $data[7];
                    $subscription = $data[8];
                    $cemetery = $data[9];
                    $house = $data[10];
                    $member_name = $data[13]; // Correctly placed member name
                    $gender = $data[14]; // Correctly placed gender
                    $relationship = $data[15]; // Correctly placed relationship
                    $dob = date('Y-m-d', strtotime($data[16])); // Correctly placed dob
                    $birth_place = $data[17]; // Correctly placed birth place
                    $qualification = $data[18]; // Correctly placed qualification
                    $occupation = $data[19]; // Correctly placed occupation

                    $baptism =  $data[20];
                    $baptism_date = $data[21];
                    $baptism_place =  $data[22];
                    $communion =  $data[23];
                    $communion_date =  $data[24];
                    $communion_place = $data[25];
                    $confirmation =  $data[26];
                    $confirmation_date =  $data[27];
                    $confirmation_place =  $data[28];
                    $married =  $data[29];
                    $married_date =  $data[30];
                    $married_place =  $data[31];
                    $alive =  $data[32];
                    $death_date = $data[33];
                    $created_at = date('Y-m-d');

                    $family_res=mysqli_query($con,"select * from families where family_no='$family_no' LIMIT 1");
                    
                    if ($family_res === false) {
                        // Query execution failed
                        echo "Error: " . mysqli_error($con);
                    } else {
                        $check=mysqli_num_rows($family_res);
                        if($check>0){
                           
                            $family_row = mysqli_fetch_assoc($family_res);
                             // Retrieve the id
                            $family_id = $family_row['id'];
                            
                            $member_res = mysqli_query($con, "INSERT INTO family_members (family_id, member_name, gender, relationship, dob, birth_place, qualification, occupation, baptism, baptism_date, baptism_place, communion, communion_date, communion_place, confirmation, confirmation_date, confirmation_place, married, married_date, married_place, alive, death_date)
                                            VALUES ('$family_id', '$member_name', '$gender', '$relationship', '$dob', '$birth_place', '$qualification', '$occupation', '$baptism', '$baptism_date', '$baptism_place', '$communion', '$communion_date', '$communion_place', '$confirmation', '$confirmation_date', '$confirmation_place', '$married', '$married_date', '$married_place', '$alive', '$death_date')");
                            if(!$member_res) {
                                echo "Error: " . mysqli_error($con);
                            }

                        }else{
                            $res = mysqli_query($con, "INSERT INTO families (family_no, anbiyam, family_name, substation, native, contact_number, address, subscription, cemetery, house, created_at)
                            VALUES ('$family_no', '$anbiyam','$family_name', '$substation', '$native', '$contact_number', '$address', '$subscription', '$cemetery', '$house', $created_at)");

                            if($res) {
                                $inserted_id = mysqli_insert_id($con);
                                $member_res = mysqli_query($con, "INSERT INTO family_members (family_id, member_name, gender, relationship, dob, birth_place, qualification, occupation, baptism, baptism_date, baptism_place, communion, communion_date, communion_place, confirmation, confirmation_date, confirmation_place, married, married_date, married_place, alive, death_date)
                                VALUES ('$inserted_id', '$member_name', '$gender', '$relationship', '$dob', '$birth_place', '$qualification', '$occupation', '$baptism', '$baptism_date', '$baptism_place', '$communion', '$communion_date', '$communion_place', '$confirmation', '$confirmation_date', '$confirmation_place', '$married', '$married_date', '$married_place', '$alive', '$death_date')");
                                if(!$member_res) {
                                    echo "Error: " . mysqli_error($con);
                                }
                            }
                        }
                    }
                
            
                
            }
            fclose($handle);
            mysqli_close($con);

            header('location:families.php');
            die();
   

        }
    }
?>