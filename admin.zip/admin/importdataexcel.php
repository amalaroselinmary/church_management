<?php
include 'connection.inc.php';

?>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Import Excel To MySQL Database Using PHP </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Import Excel File To MySql Database Using php">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-responsive.min.css">
	<link rel="stylesheet" href="css/bootstrap-custom.css">


</head>
<body>

<!-- Navbar
================================================== -->



<div id="wrap">
<div class="container">
	<div class="row">
		<div class="span3 hidden-phone"></div>
		<div class="span6" id="form-login">
			<form class="form-horizontal well" action="importdata.php" method="post" name="upload_excel" enctype="multipart/form-data">
				<fieldset>
					<legend>Import CSV/Excel file</legend>
					<div class="control-group">
						<div class="control-label">
							<label>CSV/Excel File:</label>
						</div>
						<div class="controls">
							<input type="file" name="file" id="file" class="input-large">
						</div>
					</div>
					
					<div class="control-group">
						<div class="controls">
						<button type="submit" id="submit" name="Import" class="btn btn-primary button-loading" data-loading-text="Loading...">Upload</button>
						</div>
					</div>
				</fieldset>
			</form>
		</div>    	</div>
		<div class="span3 hidden-phone"></div>
	</div>
	<div class="table-stats order-table ov-h">
					  <table class="table" id="tbl_families">
						 <thead>
							<tr>
                                <th>S.No</th>
                                <th>Family Card No</th>
								<th>Family Name</th>
								<th>Contact Number</th>
                                
							</tr>
						 </thead>
						 <tbody>
							<?php 
$sql="select * from families order by id desc";
$res=mysqli_query($con,$sql);
if (!$res) {
    // Query execution failed, handle the error
    die("Query failed: " . mysqli_error($con));
}
							$i=1;
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td class="serial"><?php echo $i++; ?></td>
							   <td><?php echo $row['family_no']?></td>
							   <td><?php echo $row['family_name']?></td>
							   <td><?php echo $row['contact_number']?></td>
							   <td>
								
							   </td>
							</tr>
							<?php } ?>
						 </tbody>
					  </table>
				   </div>

</div>

</body>
</html>