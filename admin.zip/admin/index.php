<?php
require('top.inc.php');
$family_res=mysqli_query($con,"select * from families");
$f_result = mysqli_num_rows($family_res);

$members_res=mysqli_query($con,"select * from family_members");
$m_result=mysqli_num_rows($members_res);

$baptism_res=mysqli_query($con,"select * from baptismal_list");
$b_result=mysqli_num_rows($baptism_res);

$confirmation_res=mysqli_query($con,"select * from confirmation_list");
$c_result=mysqli_num_rows($confirmation_res);

$communion_res=mysqli_query($con,"select * from communion_list");
$co_result=mysqli_num_rows($communion_res);

$death_res=mysqli_query($con,"select * from death_list");
$n_result=mysqli_num_rows($death_res);

$married_res=mysqli_query($con,"select * from married_list");
$ma_result=mysqli_num_rows($married_res);

?>
<style>
	.card {
		position: relative;
	}
	.cross {
		width: 55px;
    	height: 55px;
		border-radius: 50%;
		position: absolute;
		top: 0;
		right: 0;
	}
</style>
<div class="content pb-0">
	<div class="orders">
	   	<div class="row">
			<div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Families<h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($f_result) ? $f_result : 0 ?></p>
						<div class="cross">
							<img src="images/cross.png" class="img-fluid"  alt="">
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Members</h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($m_result) ? $m_result : 0 ?></p>
					</div>
					<div class="cross">
						<img src="images/cross.png" class="img-fluid"  alt="">
					</div>
				</div>
			</div>
			<div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Baptism</h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($b_result) ? $b_result : 0 ?></p>
					</div>
					<div class="cross">
						<img src="images/cross.png" class="img-fluid"  alt="">
					</div>
				</div>
		  	</div>
			<div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Communion</h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($co_result) ? $co_result : 0 ?></p>
					</div>
					<div class="cross">
						<img src="images/cross.png" class="img-fluid"  alt="">
					</div>
				</div>
		  	</div>
			<div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Confirmation</h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($c_result) ? $c_result : 0 ?></p>
					</div>
					<div class="cross">
						<img src="images/cross.png" class="img-fluid"  alt="">
					</div>
				</div>
		  	</div>
			<div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Married</h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($ma_result) ? $ma_result : 0 ?></p>
					</div>
					<div class="cross">
						<img src="images/cross.png" class="img-fluid"  alt="">
					</div>
				</div>
		  	</div>
			  <div class="col-sm-3">
				<div class="card">
					<div class="card-body">
						<h5 class="mb-2">Not Alive</h5>
						<p class="mb-0 font-weight-bold"><?php echo isset($n_result) ? $n_result : 0 ?></p>
					</div>
					<div class="cross">
						<img src="images/cross.png" class="img-fluid"  alt="">
					</div>
				</div>
		  	</div>
	   	</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>