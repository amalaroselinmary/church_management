<?php
require('top.inc.php');
$family_id = "";
$member_id = "";
if(isset($_GET['member_id']) && $_GET['member_id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['member_id']);
	$res=mysqli_query($con,"select * from family_members where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$family_id = $row['family_id'];
		$member_id = $row['id'];
		$married_date = $row['married_date'];
        $married_place = $row['married_place'];
		$married_res=mysqli_query($con,"select * from married_list where member_id='$id'");
		$result = mysqli_num_rows($married_res);

		if($result > 0) {
			$row1=mysqli_fetch_assoc($married_res);
            $bridegroom_name = $row1['bridegroom_name'];
            $bridegroom_marital_status = $row1['bridegroom_marital_status'];
            $bridegroom_domicile = $row1['bridegroom_domicile'];
            $bridegroom_age = $row1['bridegroom_age'];
            $bridegroom_father = $row1['bridegroom_father'];
            $bridegroom_mother = $row1['bridegroom_mother'];
            $bride_name = $row1['bride_name'];
            $bride_marital_status = $row1['bride_marital_status'];
            $bride_domicile = $row1['bride_domicile'];
            $bride_age = $row1['bride_age'];
            $bride_father = $row1['bride_father'];
            $bride_mother = $row1['bride_mother'];
            $witness1 = $row1['witness1'];
            $witness2 = $row1['witness2'];
            $minister = $row1['minister'];
		}
	}else{
		header('location:married.php');
		die();
	}
}
if(isset($_POST['submit'])){
	$family_id = $family_id;
	$member_id = $member_id ;
    $bridegroom_name = get_safe_value($con, $_POST['bridegroom_name']);
    $bridegroom_marital_status = get_safe_value($con, $_POST['bridegroom_marital_status']);
    $bridegroom_domicile = get_safe_value($con, $_POST['bridegroom_domicile']);
    $bridegroom_age = get_safe_value($con, $_POST['bridegroom_age']);
    $bridegroom_father = get_safe_value($con, $_POST['bridegroom_father']);
    $bridegroom_mother = get_safe_value($con, $_POST['bridegroom_mother']);
    $bride_name = get_safe_value($con, $_POST['bride_name']);
    $bride_marital_status = get_safe_value($con, $_POST['bride_marital_status']);
    $bride_domicile = get_safe_value($con, $_POST['bride_domicile']);
    $bride_age = get_safe_value($con, $_POST['bride_age']);
    $bride_father = get_safe_value($con, $_POST['bride_father']);
    $bride_mother = get_safe_value($con, $_POST['bride_mother']);
    $witness1 = get_safe_value($con, $_POST['witness1']);
    $witness2 = get_safe_value($con, $_POST['witness2']);
    $minister = get_safe_value($con, $_POST['minister']);
	$created_at = date("Y/m/d");

	if(isset($_GET['id']) && $_GET['id']!=''){
		$id = $_GET['id'];
		$update_sql="UPDATE married_list SET
        family_id ='$family_id',
		member_id = '$member_id', 
		bridegroom_name ='$bridegroom_name',
		bridegroom_marital_status = '$bridegroom_marital_status',
        bridegroom_domicile = '$bridegroom_domicile',
        bridegroom_age = '$bridegroom_age',
        bridegroom_father = '$bridegroom_father',
        bridegroom_mother = '$bridegroom_mother',
        bride_name ='$bride_name',
        bride_marital_status = '$bride_marital_status',
        bride_domicile = '$bride_domicile',
        bride_age = '$bride_age',
        bride_father = '$bride_father',
        bride_mother = '$bride_mother',
        witness1 = '$witness1',
        witness2 = '$witness2',
        minister = '$minister'
        WHERE id = '$id'";
		// Execute the update query
		if(mysqli_query($con, $update_sql)) {
			header('location:married.php');
			die();
		} else {
			echo "Error updating record: " . mysqli_error($con);
		}

	}else{
		$res = mysqli_query($con, "INSERT INTO married_list (family_id, member_id, bridegroom_name, bridegroom_marital_status,bridegroom_domicile, bridegroom_age, bridegroom_father, bridegroom_mother, bride_name, bride_marital_status,bride_domicile, bride_age, bride_father, bride_mother, witness1, witness2,minister, created_at) VALUES ('$family_id', '$member_id', '$bridegroom_name', '$bridegroom_marital_status', '$bridegroom_domicile', '$bridegroom_age','$bridegroom_father', '$bridegroom_mother', '$bride_name','$bride_marital_status', '$bride_domicile', '$bride_age', '$bride_father', '$bride_mother', '$witness1', '$witness2', '$minister','$created_at')");

		if($res) {
			header('location:married.php');
			die();
		}else {
			echo "Error: " . mysqli_error($con);
		}
	}
}
?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Marriage Form</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="married.php" >Back</a>
							</div>
						</div>	
					</div>
					<form method="post" enctype="multipart/form-data">
						<div class="card-body card-block">
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Marriage Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
							<div class="col-sm-4">
									<div class="form-group">
										<label for="married_date">Married Date</label>
										<input type="date"  class="form-control" disabled placeholder="" id="married_date" name="married_date" value="<?php echo isset($married_date) ? $married_date : '' ?>" />
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="married_place">Married Place</label>
										<input type="text"  class="form-control"  disabled id="married_place"   name="married_place" value="<?php echo isset($married_place) ? $married_place : '' ?>"  placeholder="Enter married place" />
										
									</div>
								</div>
								<div class="col-sm-4">
									<div class="form-group">
										<label for="minister">Minister</label>
										<input type="text" id="minister" class="form-control" placeholder="Enter minister name" name="minister" value="<?php echo isset($minister) ? $minister  : '' ?>" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Bridegroom’s Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="bridegroom_name">Bridegroom Name</label>
										<input type="text" id="bridegroom_name" class="form-control" placeholder="Enter bridegroom name" name="bridegroom_name" value="<?php echo isset($bridegroom_name) ? $bridegroom_name : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bridegroom_marital_status">Bachelor or Widower</label>
										<input type="text" id="bridegroom_marital_status" class="form-control" placeholder="Enter marital status" name="bridegroom_marital_status" value="<?php echo isset($bridegroom_marital_status) ? $bridegroom_marital_status : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bridegroom_domicile">Domicile</label>
										<input type="text" id="bridegroom_domicile" class="form-control" placeholder="Enter domicile" name="bridegroom_domicile" value="<?php echo isset($bridegroom_domicile) ? $bridegroom_domicile : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bridegroom_age">Bridegroom Age</label>
										<input type="text" id="bridegroom_age" class="form-control" placeholder="Enter bridegroom age" name="bridegroom_age" value="<?php echo isset($bridegroom_age) ? $bridegroom_age : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bridegroom_father">Bridegroom Father’s name</label>
										<input type="text" id="bridegroom_father" class="form-control" placeholder="Enter bridegroom father" name="bridegroom_father" value="<?php echo isset($bridegroom_father) ? $bridegroom_father : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bridegroom_mother">Bridegroom Mother’s Name</label>
										<input type="text" id="bridegroom_mother" class="form-control" placeholder="Enter bridegroom mother" name="bridegroom_mother" value="<?php echo isset($bridegroom_mother) ? $bridegroom_mother : '' ?>" />
									</div>
								</div>
							</div>
						
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Bride’s Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="bride_name">Bride Name</label>
										<input type="text" id="bride_name" class="form-control" placeholder="Enter bride name" name="bride_name" value="<?php echo isset($bride_name) ? $bride_name : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bride_marital_status">Spinster or Widow</label>
										<input type="text" id="bride_marital_status" class="form-control" placeholder="Enter marital status" name="bride_marital_status" value="<?php echo isset($bride_marital_status) ? $bride_marital_status : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bride_domicile">Domicile</label>
										<input type="text" id="bride_domicile" class="form-control" placeholder="Enter domicile" name="bride_domicile" value="<?php echo isset($bride_domicile) ? $bride_domicile : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bride_age">Bride Age</label>
										<input type="text" id="bride_age" class="form-control" placeholder="Enter bride age" name="bride_age" value="<?php echo isset($bride_age) ? $bride_age : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bride_father">Bride Father’s name</label>
										<input type="text" id="bride_father" class="form-control" placeholder="Enter bride father" name="bride_father" value="<?php echo isset($bride_father) ? $bride_father : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="bride_mother">Bride Mother’s Name</label>
										<input type="text" id="bride_mother" class="form-control" placeholder="Enter bride mother" name="bride_mother" value="<?php echo isset($bride_mother) ? $bride_mother : '' ?>" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<h4 class="box-title mb-3 text-primary">Witnesses Information</h4>
									<hr />
								</div>
							</div>
							<div class="row">
								<div class="col-sm-4">
									<div class="form-group">
										<label for="witness1">Witness1</label>
										<input type="text" id="witness1" class="form-control" placeholder="Enter witness1" name="witness1" value="<?php echo isset($witness1) ? $witness1 : '' ?>" />
									</div>
								</div>
                                <div class="col-sm-4">
									<div class="form-group">
										<label for="witness2">Witness2</label>
										<input type="text" id="witness2" class="form-control" placeholder="Enter witness2" name="witness2" value="<?php echo isset($witness2) ? $witness2 : '' ?>" />
									</div>
								</div>
                            </div>
							<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block">
							<span>SUBMIT</span>
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
