<?php
require('top.inc.php');
isAdmin();
$msg='';
$id= isset($_GET['id']) ? get_safe_value($con,$_GET['id']): "";

if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from married_list where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
        $bridegroom_name = $row['bridegroom_name'];
        $bridegroom_marital_status = $row['bridegroom_marital_status'];
        $bridegroom_domicile = $row['bridegroom_domicile'];
        $bridegroom_age = $row['bridegroom_age'];
        $bridegroom_father = $row['bridegroom_father'];
        $bridegroom_mother = $row['bridegroom_mother'];
        $bride_name = $row['bride_name'];
        $bride_marital_status = $row['bride_marital_status'];
        $bride_domicile = $row['bride_domicile'];
        $bride_age = $row['bride_age'];
        $bride_father = $row['bride_father'];
        $bride_mother = $row['bride_mother'];
        $witness1 = $row['witness1'];
		$witness2 = $row['witness2'];
        $minister = $row['minister'];
		$member_id = $row['member_id'];

        $member_res=mysqli_query($con,"select * from family_members where id='$member_id'");
        $result=mysqli_num_rows($res);
        if($result>0){
            $row1=mysqli_fetch_assoc($member_res);
            $married_date = $row1['married_date'];
            $married_place = $row1['married_place'];
        }

	}else{
        header('location:baptism.php');
		die();
	}
}

?>
<style>
    .table td, .table th {
        border: 0;
    }
    </style>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Marriage Certificate</h4>
							</div>
							<div class="col-6 text-right">
                                <button class="btn btn-sm btn-success" id="print">Print</button>
								<a class="btn btn-sm btn-dark"  href="<?php echo 'married.php' ?>">Back</a>
							</div>
						</div>	
					</div>
					<div  id="outprint">
                        <center><img src='images/logo.jpg' id='print-logo' /><center>
                        <div class='mx-5 pb-4'>
                            <h1 class='text-center mb-1'>Certificate of Marriage</h1>
                            <h3 class='text-center mb-1'>St.joseph's Cathedral</h3>
                            <center><small class='text-muted'>Knh Road, Dindigul - 624001 (Near Municipal Office)</small></center>
                        </div>
                        <hr class='border-navy '>
                        <fieldset>
                            <div class="card-body card-block">
                                <div class="row">
                                    <div class="col-12">
                                        <table class="table " style="width: 700px; margin:0 auto;">
                                            <tbody>
                                                <tr>
                                                    <th style="border: 0;" colspan="3">Kept at St.joseph's Cathedral / Dindigul</th>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Date of Marriage</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $married_date ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Place of Marriage</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $married_place ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Bridegroom’s Name</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bridegroom_name ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Bachelor or Widower</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bridegroom_marital_status ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Domicile</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bridegroom_domicile ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Age</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bridegroom_age ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Father’s name</th>
                                                    <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bridegroom_father ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Mother’s Name</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bridegroom_mother ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Bride’s Name</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bride_name ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Spinster or Widow</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bride_marital_status ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Domicile</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bride_domicile ?></td>
                                                </tr>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Age</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bride_age ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Father’s name</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bride_father ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Mother’s Name</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $bride_mother ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Witnesses 1</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $witness1 ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Witnesses 2</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $witness2 ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0;">Minister</th>
                                                     <td style="border: 0;">:</td>
                                                    <td style="border: 0;"><?php echo $minister ?></td>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0; text-align: right;"  colspan="3">Signature</th>
                                                </tr>
                                                <tr>
                                                    <th style="border: 0; text-align: right;" colspan="3">Designation</th>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </fieldset>
                        <div class="text-center">
                            <h4 class="font-weight-bold py-5">Seal</h4>
                        </div>
                        <div class="text-center">
                            <p class="font-weight-bold py-5">This is the true copy of the entry electronically generated</p>                        
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>