<?php
require('top.inc.php');
isAdmin();
$msg='';
$family_id = get_safe_value($con,$_GET['family_id']);
$member_name = '';
$gender = '';
$relationship = '';
$dob = '';
$birth_place = '';
$qualification = '';
$occupation = '';
$baptism = '';
$baptism_date = '';
$baptism_place = '';
$communion = '';
$communion_date = '';
$communion_place = '';
$confirmation = '';
$confirmation_date = '';
$confirmation_place = '';
$married = '';
$married_date = '';
$married_place = '';
$alive = '';
$death_date = '';

if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from family_members where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$family_id = $family_id;
		$member_name = $row['member_name'];
		$gender = $row['gender'];
		$dob = $row['dob'];
		$relationship = $row['relationship'];
		$birth_place = $row['birth_place'];
		$qualification = $row['qualification'];
		$occupation = $row['occupation'];
		$baptism = $row['baptism'];
		$baptism_date = $row['baptism_date'];
		$baptism_place = $row['baptism_place'];
		$communion = $row['communion'];
		$communion_date = $row['communion_date'];
		$communion_place = $row['communion_place'];
		$confirmation = $row['confirmation'];
		$confirmation_date = $row['confirmation_date'];
		$confirmation_place = $row['confirmation_place'];
		$married = $row['married'];
		$married_date = $row['married_date'];
		$married_place = $row['married_place'];
		$alive = $row['alive'];
		$death_date = $row['death_date'];

	}else{
		header('location:families_view.php?type=view&id='. $family_id);
		die();
	}
}


if(isset($_POST['submit'])){
	$family_id = get_safe_value($con,$_GET['family_id']);
	$member_name = get_safe_value($con, $_POST['member_name']);
	$gender = get_safe_value($con, $_POST['gender']);
	$dob = get_safe_value($con, $_POST['dob']);
	$birth_place = get_safe_value($con, $_POST['birth_place']);
	$relationship = get_safe_value($con, $_POST['relationship']);
	$qualification = get_safe_value($con, $_POST['qualification']);
	$occupation = get_safe_value($con, $_POST['occupation']);
	$baptism = get_safe_value($con, isset($_POST['baptism']) ? 1 : 0);
	$baptism_date = get_safe_value($con, $_POST['baptism_date']);
	$baptism_place = get_safe_value($con, $_POST['baptism_place']);
	$communion = get_safe_value($con, isset($_POST['communion']) ? 1 : 0);
	$communion_date = get_safe_value($con, $_POST['communion_date']);
	$communion_place = get_safe_value($con, $_POST['communion_place']);
	$confirmation = get_safe_value($con, isset($_POST['confirmation']) ? 1 : 0);
	$confirmation_date = get_safe_value($con, $_POST['confirmation_date']);
	$confirmation_place = get_safe_value($con, $_POST['confirmation_place']);
	$married = get_safe_value($con, isset($_POST['married']) ? 1 : 0);
	$married_date = get_safe_value($con, $_POST['married_date']);
	$married_place = get_safe_value($con, $_POST['married_place']);
	$alive = get_safe_value($con, isset($_POST['alive']) ? 1 : 0);
	$death_date = get_safe_value($con, $_POST['death_date']);

	if(isset($_GET['id']) && $_GET['id']!=''){
		$update_sql="UPDATE family_members SET 
        family_id = '$family_id',
        member_name = '$member_name',
        gender = '$gender',
        relationship = '$relationship',
        dob = '$dob',
        birth_place = '$birth_place',
        qualification = '$qualification',
        occupation = '$occupation',
        baptism = '$baptism',
        baptism_date = '$baptism_date',
        baptism_place = '$baptism_place',
        communion = '$communion',
        communion_date = '$communion_date',
        communion_place = '$communion_place',
		confirmation = '$confirmation',
        confirmation_date = '$confirmation_date',
        confirmation_place = '$confirmation_place',
        married = '$married',
        married_date = '$married_date',
        married_place = '$married_place',
        alive = '$alive',
        death_date = '$death_date'
        WHERE id = '$id'";
		// Execute the update query
		if(mysqli_query($con, $update_sql)) {
			header('location:families_view.php?type=view&id='. $family_id);
			die();
		} else {
			echo "Error updating record: " . mysqli_error($con);
		}

	}else{
		
		$res = mysqli_query($con, "INSERT INTO family_members (family_id, member_name, gender, relationship, dob, birth_place, qualification, occupation, baptism, baptism_date, baptism_place, communion, communion_date, communion_place, confirmation, confirmation_date, confirmation_place, married, married_date, married_place, alive, death_date) VALUES ('$family_id', '$member_name', '$gender', '$relationship', '$dob', '$birth_place', '$qualification', '$occupation', '$baptism', '$baptism_date', '$baptism_place', '$communion', '$communion_date', '$communion_place', '$confirmation', '$confirmation_date', '$confirmation_place', '$married', '$married_date', '$married_place', '$alive', '$death_date')");

		if($res) {
			header('location:families_view.php?type=view&id='. $family_id);
			die();
		}else {
			echo "Error: " . mysqli_error($con);
		}
	}
}
?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Member FORM</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="<?php echo 'families_view.php?type=view&id='. $family_id ?>" >Back</a>
							</div>
						</div>	
					</div>
					<form method="post" id="member_form" enctype="multipart/form-data">
						<div class="accordion" id="accordionExample">
							<div class="card-body card-block">
								<div class="row">
									<div class="col-12">
									<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0 accordion-button" type="button" data-toggle="collapse" data-target="#collapseGeneral" aria-expanded="true" aria-controls="collapseGeneral">General Information</button>
										<hr />
									</div>
								</div>
								<div id="collapseGeneral" class="collapse show accordion-item" aria-labelledby="generalInformation" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<label for="member_name">Member Name</label>
												<input type="text" id="member_name" class="form-control" placeholder="Enter member name" name="member_name" value="<?php echo $member_name?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="Roles">Role/Relationship</label>
												<select class="form-control" id="relationship"  name="relationship" aria-label="">
													<option value="">Select Relationship</option>
													<!-- <option value="FamilyHead" < ?php echo $relationship == 'FamilyHead' ? 'selected': '' ?>>Family Head</option> -->
													<option value="Son" <?php echo $relationship == 'Son' ? 'selected': '' ?>>Son</option>
													<option value="Daughter" <?php echo $relationship == 'Daughter' ? 'selected': '' ?>>Daughter</option>
													<option value="Father" <?php echo $relationship == 'Father' ? 'selected': '' ?>>Father</option>
													<option value="Mother" <?php echo $relationship == 'Mother' ? 'selected': '' ?>>Mother</option>
													<option value="Others" <?php echo $relationship == 'Others' ? 'selected': '' ?>>Others</option>
												</select>
												
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="gender">Gender</label>
												<select class="form-control" id="gender" name="gender" aria-label="">
													<option value="">Select Gender</option>
													<option value="Male" <?php echo $gender == 'Male' ? 'selected': '' ?>>Male</option>
													<option value="Female" <?php echo $gender == 'Female' ? 'selected': '' ?>>Female</option>
												</select>
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<label for="dob">Date of Birth</label>
												<input type="date" id="dob" class="form-control" name="dob"  placeholder="" value="<?php echo $dob?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="birth_place">Birth Place</label>
												<input type="text" id="birth_place" class="form-control"
												name="birth_place"
													placeholder="Enter birth place" value="<?php echo $birth_place ?>" />
											</div>
										</div> 
										<div class="col-sm-4">
											<div class="form-group">
												<label for="qualification">Qualification</label>
												<input type="text" id="qualification" class="form-control"
												name="qualification"
													placeholder="Enter qualification" value="<?php echo $qualification ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label for="occupation">Occupation</label>
												<input type="text"  class="form-control" id="occupation" 
												name="occupation" placeholder="Enter occupation" value="<?php echo $occupation ?>" />
											</div>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12">
										<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0 accordion-button" type="button" data-toggle="collapse" data-target="#collapseSacraments" aria-expanded="true" aria-controls="collapseSacraments">Sacraments Details</button>
										<hr />
									</div>
								</div>
								<div id="collapseSacraments" class="collapse show accordion-item" aria-labelledby="sacramentsDetails" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<label for="baptism">Baptism (yes/No)?</label>
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="baptism" type="checkbox" id="baptism" name="baptism" <?php echo isset($baptism) && $baptism == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group baptism-fields" style="display: <?php echo isset($baptism) && $baptism == '1' ? 'block' : 'none'; ?>">
												<label for="baptism_date">Baptism Date</label>
												<input type="date" class="form-control" placeholder="" id="baptism_date" name="baptism_date" value="<?php echo isset($baptism_date) ? $baptism_date : '' ?>" />
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group  baptism-fields" style="display: <?php echo isset($baptism) && $baptism == '1' ? 'block' : 'none'; ?>">
												<label for="baptism_place">Baptism Place</label>
												<input type="text" class="form-control" id="baptism_place" name="baptism_place" value="<?php echo isset($baptism_place) ? $baptism_place : '' ?>" placeholder="Enter baptism place" />
											</div>
										</div>
									</div>
									<div class="row">
												<div class="col-sm-4">
													<label for="communion">Holy Communion?</label>
													<div class="form-check form-switch">
														<input class="form-check-input event-checkbox" data-event="communion" type="checkbox" id="communion" 
														name="communion"  <?php echo isset($communion) && $communion == '1' ? 'checked': '' ?>>
													</div>                
												</div>
												<div class="col-sm-4">
													<div class="form-group communion-fields" style="display: <?php echo isset($communion) && $communion == '1' ? 'block' : 'none'; ?>">
														<label for="communion_date">Communion Date</label>
														<input type="date"  class="form-control" placeholder="" id="communion_date" value="<?php echo isset($communion_date) ? $communion_date : '' ?>" name="communion_date"/>
													</div>
												</div>
												<div class="col-sm-4">
													<div class="form-group communion-fields" style="display: <?php echo isset($communion) && $communion == '1' ? 'block' : 'none'; ?>">
														<label for="communion_place">Communion Place</label>
														<input type="text"  class="form-control" id="communion_place"   name="communion_place" value="<?php echo isset($communion_place) ? $communion_place : '' ?>"   placeholder="Enter communion place" />
														
													</div>
												</div>
									</div>
									<div class="row">
										<div class="col-sm-4">
											<label for="confirmation">Confirmation?</label>
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="confirmation" type="checkbox" id="confirmation" 
												name="confirmation"  <?php echo isset($confirmation) && $confirmation == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group confirmation-fields" style="display: <?php echo isset($confirmation) && $confirmation == '1' ? 'block' : 'none'; ?>">
												<label for="confirmation_date">Confirmation Date</label>
												<input type="date"  class="form-control" placeholder="" id="confirmation_date" value="<?php echo isset($confirmation_date) ? $confirmation_date : '' ?>" name="confirmation_date"/>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group confirmation-fields" style="display: <?php echo isset($confirmation) && $confirmation == '1' ? 'block' : 'none'; ?>">
												<label for="confirmation_place">Confirmation Place</label>
												<input type="text"  class="form-control" id="confirmation_place"   name="confirmation_place" value="<?php echo isset($confirmation_place) ?$confirmation_place : '' ?>"   placeholder="Enter confirmation place" />
												
											</div>
										</div>
									</div>
									<div class="row">
										<div class="col-sm-4">
											<label for="married">Married?</label>
											<div class="form-check form-switch">
												<input class="form-check-input event-checkbox" data-event="married" type="checkbox" id="married" name="married"  <?php echo isset($married) && $married == '1' ? 'checked': '' ?>>
											</div>                
										</div>
										<div class="col-sm-4">
											<div class="form-group married-fields" style="display: <?php echo isset($married) && $married == '1' ? 'block' : 'none'; ?>">
												<label for="married_date">Married Date</label>
												<input type="date"  class="form-control" placeholder="" id="married_date" value="<?php echo isset($married_date) ? $married_date : '' ?>" name="married_date"/>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group married-fields" style="display: <?php echo isset($married) && $married == '1' ? 'block' : 'none'; ?>">
												<label for="married_place">Married Place</label>
												<input type="text"  class="form-control" id="married_place"   name="married_place" value="<?php echo isset($married_place) ?$married_place : '' ?>"  placeholder="Enter married place" />
												
											</div>
										</div>
									</div>
									<div class="row">  
										<div class="col-lg-4"> Is Alive?
												<div class="form-check form-switch">
													<input class="form-check-input event-checkbox" data-event="alive" type="checkbox" checked id="alive"
													name="alive" <?php echo isset($alive) && $alive == '1' ? 'checked': '' ?>>
											</div>
										</div>
										<div class="col-sm-4">
										<div class="form-group alive-fields" style="display: <?php echo isset($alive) && $alive == 1 ? 'none' : 'block'; ?>">
											<label for="deathDate">Date of Death</label>
											<input type="date" class="form-control" value="<?php echo isset($death_date) ? $death_date : ''; ?>" placeholder="" id="deathDate" name="death_date" />
										</div>
									</div>
								</div>
								<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block"><span>SUBMIT</span></button>
								<div class="field_error"><?php echo $msg?></div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>