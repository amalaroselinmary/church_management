<?php
require('top.inc.php');
isAdmin();
$msg='';
$id= isset($_GET['id']) ? get_safe_value($con,$_GET['id']): "";
$family_id = get_safe_value($con,$_GET['family_id']);
$member_name = "";
$gender = "";
$dob = "";
$relationship = "";
$birth_place = "";
$qualification = "";
$occupation = "";
$baptism = "";
$baptism_date = "";
$baptism_place = "";
$communion = "";
$communion_date = "";
$communion_place = "";
$confirmation = "";
$confirmation_date = "";
$confirmation_place = "";
$married = "";
$married_date = "";
$married_place = "";
$alive = "";
$death_date = "";

if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from family_members where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$member_name = $row['member_name'];
		$gender = $row['gender'];
		$dob = $row['dob'];
        $relationship = $row['relationship'];
		$birth_place = $row['birth_place'];
		$qualification = $row['qualification'];
		$occupation = $row['occupation'];
		$baptism = $row['baptism'];
		$baptism_date = $row['baptism_date'];
		$baptism_place = $row['baptism_place'];
		$communion = $row['communion'];
		$communion_date = $row['communion_date'];
		$communion_place = $row['communion_place'];
		$confirmation = $row['confirmation'];
		$confirmation_date = $row['confirmation_date'];
		$confirmation_place = $row['confirmation_place'];
		$married = $row['married'];
		$married_date = $row['married_date'];
		$married_place = $row['married_place'];
		$alive = $row['alive'];
		$death_date = $row['death_date'];

		// Confirmation List
		$c_res = mysqli_query($con, "SELECT id, COUNT(*) AS confirmation_count FROM confirmation_list WHERE member_id ='$id' LIMIT 1");
		$c_row = mysqli_fetch_assoc($c_res);

		// Baptism List
		$b_res = mysqli_query($con, "SELECT id, COUNT(*) AS baptism_count FROM baptismal_list WHERE member_id ='$id' LIMIT 1");
		$b_row = mysqli_fetch_assoc($b_res);

		// Communion List
		$co_res = mysqli_query($con, "SELECT id, COUNT(*) AS communion_count FROM communion_list WHERE member_id ='$id' LIMIT 1");
		$co_row = mysqli_fetch_assoc($co_res);

		// Married List
		$m_res = mysqli_query($con, "SELECT id, COUNT(*) AS married_count FROM married_list WHERE member_id ='$id' LIMIT 1");
		$m_row = mysqli_fetch_assoc($m_res);
		// Death List
		$d_res = mysqli_query($con, "SELECT id, COUNT(*) AS death_count FROM death_list WHERE member_id ='$id' LIMIT 1");
		$d_row = mysqli_fetch_assoc($d_res);

	}else{
        header('location:families_view.php?type=view&id='. $id);;
		die();
	}
}

?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Member View</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark"  href="<?php echo 'families_view.php?type=view&id='. $family_id ?>">Back</a>
							</div>
						</div>	
					</div>
					<form method="post" enctype="multipart/form-data">
						<div class="accordion" id="accordionExample">
							<div class="card-body card-block">
								<div class="row">
									<div class="col-12">
									<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0" type="button" data-toggle="collapse" data-target="#collapseGeneral" aria-expanded="true" aria-controls="collapseGeneral">General Information</button>
									</div>
								</div>
								<hr>
								<div id="collapseGeneral" class="collapse show" aria-labelledby="generalInformation" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="memberName">Member Name</label>
												<p> <?php echo $member_name?> </p>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="relationship">Role / Relationship</label>
												<p> <?php echo $relationship ?> </p>
											</div>
										</div>
									
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="gender">Gender</label>
												<p><?php echo $gender ?></p>
											</div>
										</div>
										
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="dob">Date of Birth</label>
												<p><?php echo $dob?></p>
											</div>
										</div>
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="birthPlace">Birth Place</label>
												<p><?php echo $birth_place ?></p>
											</div>
										</div> 
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="qualification">Qualification</label>
												<p><?php echo $qualification ?></p>
											</div>
										</div>
									
										<div class="col-sm-4">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="occupation">Occupation</label>
												<p><?php echo $occupation ?></p>
											</div>
										</div>
									</div>
								</div>
								
								<div class="row">
									<div class="col-12">
									<button class="btn btn-collapse btn-link btn-block text-left box-title text-primary p-0" type="button" data-toggle="collapse" data-target="#collapseSacraments" aria-expanded="true" aria-controls="collapseSacraments">Sacraments Details</button>
										<hr />
									</div>
								</div>
								<div id="collapseSacraments" class="collapse show" aria-labelledby="sacramentsDetails" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-3">
											<label class="font-weight-bold  text-secondary" for="baptism">Baptism (yes/No)?</label>
											<div class="form-check form-switch">
												<p><?php echo $baptism == '1' ? 'Yes': 'No' ?></p>
											</div>                
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="baptismDate">Baptism Date</label>
												<p><?php echo $baptism_date ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="baptismPlace">Baptism Place</label>
												<p><?php echo $baptism_place ?></p>
												
											</div>
										</div>
										<?php if($baptism && $b_row['baptism_count'] <= 0) { ?>
										<div class="col-sm-3">
											<a href=<?php echo "baptism_manage.php?member_id=".$id."" ?> class="btn btn-sm btn-dark">Create/View</a>
										</div>
										<?php } else if($baptism && $b_row['baptism_count'] > 0){?>
											<div class="col-sm-3">
											<a href="baptism_view.php?type=view&id=<?php echo $b_row['id'] ?>"class="btn btn-sm btn-info">View / Print</a>
											</div>
										<?php } ?>
									</div>  
									<div class="row">
										<div class="col-sm-3">
											<label class="font-weight-bold  text-secondary" for="communion">Holy Communion?</label>
											<div class="form-check form-switch">
											<p><?php echo $communion == '1' ? 'Yes': 'No' ?></p>
											</div>                
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="communionDate">Communion Date</label>
												<p><?php echo $communion_date ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="communionPlace">Communion Place</label>
												<p><?php echo $communion_place ?></p>
												
											</div>
										</div>
										<?php if($communion && $co_row['communion_count'] <= 0) { ?>
										<div class="col-sm-3">
											<a href=<?php echo "communion_manage.php?member_id=".$id."" ?> class="btn btn-sm btn-dark">Create/View</a>
										</div>
										<?php } else if($communion && $co_row['communion_count'] > 0) {?>
											<div class="col-sm-3">
											<a href="communion_view.php?type=view&id=<?php echo $co_row['id'] ?>"class="btn btn-sm btn-info">View / Print</a>
											</div>
										<?php } ?>
									</div>
									<div class="row">
										<div class="col-sm-3">
											<label class="font-weight-bold  text-secondary" for="communion">Confirmation?</label>
											<div class="form-check form-switch">
											<p><?php echo $confirmation == '1' ? 'Yes': 'No' ?></p>
											</div>                
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="confirmationDate">Confirmation Date</label>
												<p><?php echo $confirmation_date ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="confirmationPlace">Confirmation Place</label>
												<p><?php echo $confirmation_place ?></p>
												
											</div>
										</div>
										<?php if($confirmation && $c_row['confirmation_count'] <= 0) { ?>
											<div class="col-sm-3">
												<a href=<?php echo "confirmation_manage.php?member_id=".$id."" ?> class="btn btn-sm btn-dark">Create/View</a>
											</div>
										<?php } else if($confirmation && $c_row['confirmation_count'] > 0) {?>
											<div class="col-sm-3">
											<a href="confirmation_view.php?type=view&id=<?php echo $c_row['id'] ?>"class="btn btn-sm btn-info">View / Print</a>
											</div>
										<?php } ?>
									</div>
									<div class="row">
										<div class="col-sm-3">
											<label class="font-weight-bold  text-secondary" for="married">Married?</label>
											<div class="form-check form-switch">
											<p><?php echo $married == '1' ? 'Yes': 'No' ?></p>
											</div>                
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="marriedDate">Married Date</label>
												<p><?php echo $married_date ?> </p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="marriedPlace">Married Place</label>
												<p><?php echo $married_place ?></p>
											</div>
										</div>
										<?php if($married && $m_row['married_count'] <= 0) { ?>
										<div class="col-sm-3">
											<a href=<?php echo "married_manage.php?member_id=".$id."" ?> class="btn btn-sm btn-dark">Create/View</a>
										</div>
										<?php } else if($married && $m_row['married_count'] > 0) {?>
											<div class="col-sm-3">
											<a href="married_view.php?type=view&id=<?php echo $m_row['id'] ?>"class="btn btn-sm btn-info">View / Print</a>
											</div>
										<?php } ?>
										
									</div>
									<div class="row">  
										<div class="col-lg-3"> Is Alive?
												<div class="form-check form-switch">
													<p><?php echo $alive == '1' ? 'Yes': 'No' ?></p>
											</div>
										</div>
										<div class="col-sm-3">
											<div class="form-group">
												<label class="font-weight-bold  text-secondary" for="deathDate">Date of Death</label>
												<p><?php echo $death_date ?></p>
											</div>
										</div>
										<div class="col-sm-3 d-none d-sm-block"></div>
										<?php if(!$alive && $d_row['death_count'] <= 0) { ?>
										<div class="col-sm-3">
											<a href=<?php echo "death_manage.php?member_id=".$id."" ?> class="btn btn-sm btn-dark">Create/View</a>
										</div>
										<?php } else if(!$alive && $d_row['death_count'] > 0) {?>
											<div class="col-sm-3">
											<a href="death_view.php?type=view&id=<?php echo $d_row['id'] ?>"class="btn btn-sm btn-info">View / Print</a>
											</div>
										<?php } ?>
										
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>