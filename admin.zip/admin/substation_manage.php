<?php
require('top.inc.php');
isAdmin();


if(isset($_GET['id']) && $_GET['id']!=''){
	$image_required='';
	$id=get_safe_value($con,$_GET['id']);
	$res=mysqli_query($con,"select * from substations where id='$id'");
	$check=mysqli_num_rows($res);
	if($check>0){
		$row=mysqli_fetch_assoc($res);
		$name = $row['substation_name'];
        $s_id = $row['id'];
		$created_at = $row['created_at'];
	}else{
		header('location:substations.php');
		die();
	}
}


if(isset($_POST['submit'])){
	$name  = get_safe_value($con, $_POST['name']);
	$created_at =  date("Y/m/d");

	if(isset($_GET['id']) && $_GET['id']!=''){
		$update_sql="UPDATE substations SET 
        substation_name = '$name'
        WHERE id = '$s_id'";
		// Execute the update query
		if(mysqli_query($con, $update_sql)) {
			header('location:substations.php');
			die();
		} else {
			echo "Error updating record: " . mysqli_error($con);
		}

	}else{
		
		$res = mysqli_query($con, "INSERT INTO substations (substation_name, created_at) VALUES ('$name','$created_at')");

		if($res) {
			header('location:substations.php');
			die();
		}else {
			echo "Error: " . mysqli_error($con);
		}
	}
}
?>
<div class="content pb-0">
	<div class="animated fadeIn">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">SUBSTATION FORM</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-dark" href="<?php echo 'families_view.php' ?>" >Back</a>
							</div>
						</div>	
					</div>
					<form method="post" id="substation_form" enctype="multipart/form-data">
						<div class="accordion" id="accordionExample">
							<div class="card-body card-block">
								<div id="collapseGeneral" class="collapse show accordion-item" aria-labelledby="generalInformation" data-parent="#accordionExample">
									<div class="row">
										<div class="col-sm-4">
											<div class="form-group">
												<label for="name">Name</label>
												<input type="text" id="name" class="form-control" placeholder="Enter name" name="name" value="<?php echo isset($name) ? $name : '' ?>" />
											</div>
										</div>
										
									</div>
								</div>
								<button  name="submit" type="submit" class="btn btn-lg btn-success btn-block"><span>SUBMIT</span></button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require('footer.inc.php');
?>