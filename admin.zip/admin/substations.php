<?php
require('top.inc.php');
isAdmin();
if(isset($_GET['type']) && $_GET['type']!=''){
	$type=get_safe_value($con,$_GET['type']);
	if($type=='delete'){
		$id=get_safe_value($con,$_GET['id']);
		$delete_sql="delete from substations where id='$id'";
		$delete_res = mysqli_query($con,$delete_sql); 
		if($delete_res) {
			header('location:substations.php');
			die();
		}
	}
}

$sql="SELECT * FROM substations ORDER BY id DESC";
$res=mysqli_query($con,$sql);
if (!$res) {
    // Query execution failed, handle the error
    die("Query failed: " . mysqli_error($con));
}

?>
<div class="content pb-0">
	<div class="orders">
	   <div class="row">
		  <div class="col-xl-12">
			 <div class="card">
				<div class="card-body">
					<div class="accordion" id="accordionExample">
						<div class="row">
							<div class="col-6">
								<h4 class="box-title">Substations</h4>
							</div>
							<div class="col-6 text-right">
								<a class="btn btn-sm btn-primary" href="<?php echo 'substation_manage.php' ?>">ADD NEW</a>
							</div>
						</div>
					</div>
				   <div class="table-stats order-table ov-h">
					  <table class="table" id="tbl_families">
						 <thead>
							<tr>
                                <th>S.No</th>
								<th>Name</th>
                                <th>created_at</th>
								<th>Actions</th>
							</tr>
						 </thead>
						 <tbody>
							<?php 
							$i=1; 
							if(isset($res)){
							while($row=mysqli_fetch_assoc($res)){?>
							<tr>
							   <td class="serial"><?php echo $i++; ?></td>
							   <td><?php echo $row['substation_name']?></td>
							   <td><?php echo $row['created_at']?></td>

							   <td>
								<?php
                                    echo "<span class='badge badge-secondary'><a href='substation_manage.php?id=".$row['id']."'>Edit</a></span>&nbsp;";
                                    
                                    echo "<span class='badge badge-danger'><a href='?type=delete&id=".$row['id']."'>Delete</a></span>";
                                    
								?>
							   </td>
							</tr>
							<?php } }?>
						 </tbody>
					  </table>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
</div>
<?php
require('footer.inc.php');
?>
